const r=""+new URL("upAvatar.88eb1fd1.svg",import.meta.url).href;export{r as _};
