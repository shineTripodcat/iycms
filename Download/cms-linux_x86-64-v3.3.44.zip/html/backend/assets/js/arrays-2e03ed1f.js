const e=t=>[...new Set(t)],n=t=>!t&&t!==0?[]:Array.isArray(t)?t:[t];export{n as c,e as u};
