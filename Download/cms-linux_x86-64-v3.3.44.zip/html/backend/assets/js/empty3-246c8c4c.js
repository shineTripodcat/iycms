const e=""+new URL("../png/empty3-368eb144.png",import.meta.url).href;export{e as _};
