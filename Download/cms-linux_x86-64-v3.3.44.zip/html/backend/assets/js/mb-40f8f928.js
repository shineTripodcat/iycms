import{R as t}from"./entry-9cc5c370.js";const r=()=>t({url:"/tpl/all",method:"get"});export{r as g};
