import{R as e}from"./entry-9cc5c370.js";const o=t=>e({url:"/category/all/"+t,method:"get"}),a=(t,r)=>e({url:`/sites/${r}/category/all/`+t,method:"get"});export{o as a,a as g};
