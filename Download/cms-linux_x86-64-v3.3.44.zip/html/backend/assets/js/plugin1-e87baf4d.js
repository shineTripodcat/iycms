const p=""+new URL("../png/plugin1-adfdab1e.png",import.meta.url).href;export{p as _};
