const p=""+new URL("../png/plugin9-f16e48cf.png",import.meta.url).href;export{p as _};
