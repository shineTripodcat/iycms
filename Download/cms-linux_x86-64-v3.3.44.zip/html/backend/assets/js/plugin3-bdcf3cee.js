const p=""+new URL("../png/plugin3-f58d65fd.png",import.meta.url).href;export{p as _};
