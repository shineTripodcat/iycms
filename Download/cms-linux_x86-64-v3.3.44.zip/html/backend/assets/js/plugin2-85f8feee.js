const p=""+new URL("../png/plugin2-1ed80539.png",import.meta.url).href;export{p as _};
