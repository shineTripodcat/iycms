import{R as e}from"./entry-9cc5c370.js";const r={get(){return e({url:"/system/plugin/member",method:"get"})},set(t){return e({url:"/system/plugin/member",method:"put",data:t})}};export{r as m};
