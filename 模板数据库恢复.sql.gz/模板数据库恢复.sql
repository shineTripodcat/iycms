-- MySQL dump 10.13  Distrib 8.0.41, for Linux (x86_64)
--
-- Host: 172.18.0.3    Database: iycms
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ads`
--

DROP TABLE IF EXISTS `ads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ads` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '广告名称',
  `position` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '位置',
  `ads_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '广告类型 image图片 text文字 custom自定义',
  `custom` text COLLATE utf8mb4_unicode_ci COMMENT '自定义内容',
  `content` text COLLATE utf8mb4_unicode_ci COMMENT '内容',
  `link` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '链接',
  `sort` bigint NOT NULL COMMENT '排序',
  `state` bigint NOT NULL COMMENT '状态 1显示 2关闭',
  `close` bigint NOT NULL COMMENT '允许关闭 1允许 2不允许',
  `duration` bigint NOT NULL COMMENT '显示时长 单位秒',
  `create_at` bigint NOT NULL,
  `online_at` bigint NOT NULL DEFAULT '0',
  `offline_at` bigint NOT NULL DEFAULT '0',
  `update_at` bigint NOT NULL,
  `target` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '_self',
  `is_all_site` int NOT NULL DEFAULT '2' COMMENT '是否是全站应用,1-是，2-否',
  `ad_timer` int NOT NULL DEFAULT '0' COMMENT '定时器',
  `terminal` int NOT NULL DEFAULT '7' COMMENT '终端web h5 app',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ads`
--

LOCK TABLES `ads` WRITE;
/*!40000 ALTER TABLE `ads` DISABLE KEYS */;
/*!40000 ALTER TABLE `ads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ads_position`
--

DROP TABLE IF EXISTS `ads_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ads_position` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '广告位名称',
  `english_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '英文标识',
  `ads_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '广告类型,多个用西文逗号分割 image图片 text文字 custom自定义',
  `sort` bigint NOT NULL COMMENT '排序',
  `state` bigint NOT NULL COMMENT '状态 1显示 2关闭',
  `can_update` tinyint(1) DEFAULT NULL COMMENT '是否允许修改标识',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_en_name` (`english_name`),
  KEY `idx_ads_position_site_id` (`site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ads_position`
--

LOCK TABLES `ads_position` WRITE;
/*!40000 ALTER TABLE `ads_position` DISABLE KEYS */;
INSERT INTO `ads_position` VALUES (1,'左上漂浮广告','floatLeftTop','image',0,1,0,1744374475,1744374475,0),(2,'左中漂浮广告','floatLeft','image',1,1,0,1744374475,1744374475,0),(3,'左下漂浮广告','floatLeftBottom','image',2,1,0,1744374475,1744374475,0),(4,'上部漂浮广告','floatTop','image',3,1,0,1744374475,1744374475,0),(5,'居中漂浮广告','floatCenter','image',4,1,0,1744374475,1744374475,0),(6,'底部漂浮广告','floatBottom','image',5,1,0,1744374475,1744374475,0),(7,'右上漂浮广告','floatRightTop','image',6,1,0,1744374475,1744374475,0),(8,'右中漂浮广告','floatRightCenter','image',7,1,0,1744374475,1744374475,0),(9,'右下漂浮广告','floatRightBottom','image',8,1,0,1744374475,1744374475,0),(10,'上部通用横幅广告','topBanner','image,text,custom',9,1,0,1744374475,1744374475,0),(11,'底部通用横幅广告','bottomBanner','image,text,custom',10,1,0,1744374475,1744374475,0),(12,'播放器上广告','playerUp','image,text,custom',11,1,0,1744374475,1744374475,0),(13,'播放器下广告','playerDown','image,text,custom',12,1,0,1744374475,1744374475,0),(14,'播放前广告','beforePlay','image,video',13,1,0,1744374475,1744374475,0),(15,'播放暂停广告','pausePlay','image',14,1,0,1744374475,1744374475,0),(16,'首页轮播广告','banner','image',15,1,0,1744374475,1744374475,0),(17,'Slogan广告','slogan','image',16,1,0,1744374475,1744374475,0),(18,'首页弹出广告','homePop','image',17,1,0,1744374475,1744374475,0),(19,'引导页广告','boot','image',18,1,0,1744374475,1744374475,0),(20,'通用自定义广告','generalCustom','custom',19,1,0,1744374475,1744374475,0);
/*!40000 ALTER TABLE `ads_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_address`
--

DROP TABLE IF EXISTS `agent_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_address` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `member_id` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '代理id',
  `address_serial` bigint NOT NULL DEFAULT '0' COMMENT '代理地址排序,默认升序',
  `address` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '代理地址',
  `is_default` int NOT NULL DEFAULT '0' COMMENT '是否默认{0:否,1:是}',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_address`
--

LOCK TABLES `agent_address` WRITE;
/*!40000 ALTER TABLE `agent_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `agent_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_brokerage`
--

DROP TABLE IF EXISTS `agent_brokerage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_brokerage` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `member_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '会员id',
  `agent_level_id` bigint NOT NULL DEFAULT '0' COMMENT '代理等级id',
  `agent_level_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '代理等级名称',
  `category` bigint NOT NULL DEFAULT '0' COMMENT '提成类型{100:首充,200:续费,300:金币,400:团队}',
  `title` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
  `recharge_member_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '充值会员id',
  `recharge_member_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '充值会员用户名',
  `recharge_amount` double NOT NULL DEFAULT '0' COMMENT '充值金额',
  `recharge_attach` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '充值说明',
  `brokerage_scale` double NOT NULL DEFAULT '0' COMMENT '佣金比例',
  `amount1` double NOT NULL DEFAULT '0' COMMENT '变化前金额',
  `amount2` double NOT NULL DEFAULT '0' COMMENT '变化的金额',
  `amount3` double NOT NULL DEFAULT '0' COMMENT '变化后金额',
  `brokerage_at` bigint NOT NULL DEFAULT '0' COMMENT '提成时间(目前根据业务和创建时间一致)',
  `paid_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '支付方式',
  `paid_no` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '支付订单号',
  `attach` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '附加说明',
  `recharge_ip` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '充值ip',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_agent_brokerage_member_id` (`member_id`),
  KEY `idx_agent_brokerage_category` (`category`),
  KEY `idx_agent_brokerage_recharge_member_id` (`recharge_member_id`),
  KEY `idx_agent_brokerage_recharge_member_name` (`recharge_member_name`),
  KEY `idx_agent_brokerage_recharge_attach` (`recharge_attach`),
  KEY `idx_agent_brokerage_recharge_ip` (`recharge_ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_brokerage`
--

LOCK TABLES `agent_brokerage` WRITE;
/*!40000 ALTER TABLE `agent_brokerage` DISABLE KEYS */;
/*!40000 ALTER TABLE `agent_brokerage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_brokerage_withdraw`
--

DROP TABLE IF EXISTS `agent_brokerage_withdraw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_brokerage_withdraw` (
  `id` int NOT NULL AUTO_INCREMENT,
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  `val` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'json字符串',
  `create_at` int NOT NULL DEFAULT '0',
  `update_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `agent_brokerage_withdraw_siteid_index` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='佣金提现配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_brokerage_withdraw`
--

LOCK TABLES `agent_brokerage_withdraw` WRITE;
/*!40000 ALTER TABLE `agent_brokerage_withdraw` DISABLE KEYS */;
/*!40000 ALTER TABLE `agent_brokerage_withdraw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_level`
--

DROP TABLE IF EXISTS `agent_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_level` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '等级名称',
  `performance_min` double NOT NULL DEFAULT '0' COMMENT '最低业绩{0:不限制}',
  `performance_max` double NOT NULL DEFAULT '0' COMMENT '最高业绩{0:不限制}',
  `performance_day` double NOT NULL DEFAULT '0' COMMENT '当日最低业绩{0:无效}',
  `performance_logic` tinyint NOT NULL DEFAULT '0' COMMENT '累计业绩和当日业绩逻辑关系{0:或,1:且}',
  `level_serial` bigint NOT NULL DEFAULT '0' COMMENT '代理等级唯一排序,值越大越优先',
  `brokerage_scale_first_recharge` double NOT NULL DEFAULT '0' COMMENT '首充提成比例',
  `brokerage_scale_renewal` double NOT NULL DEFAULT '0' COMMENT '续费提成比例',
  `brokerage_scale_gold` double NOT NULL DEFAULT '0' COMMENT '金币提成比例',
  `brokerage_scale_team` double NOT NULL DEFAULT '0' COMMENT '团队提成比例',
  `withdraw_min` double NOT NULL DEFAULT '0' COMMENT '最低提现金额,最低100,整数倍数',
  `withdraw_day_times` bigint NOT NULL DEFAULT '0' COMMENT '每天提现的次数,最少一次',
  `withdraw_fee` double NOT NULL DEFAULT '0' COMMENT '提现手续费比例',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `site_id` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_name` (`level_serial`),
  UNIQUE KEY `agent_level_siteid_level_index` (`site_id`,`level_serial`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_level`
--

LOCK TABLES `agent_level` WRITE;
/*!40000 ALTER TABLE `agent_level` DISABLE KEYS */;
INSERT INTO `agent_level` VALUES (1,'普通代理',0,49,0,0,1,0.5,0.3,0.3,0.03,100,1,0,1744374684,1744374684,1),(2,'高级代理',50,199,100,0,2,0.6,0.3,0.3,0.03,100,1,0,1744374684,1744374684,1),(3,'超级代理',200,499,300,0,3,0.7,0.3,0.3,0.03,100,1,0,1744374684,1744374684,1),(4,'至尊代理',500,999,700,0,4,0.8,0.4,0.4,0.04,100,1,0,1744374684,1744374684,1),(5,'特约代理',1000,4999,1000,0,5,0.8,0.6,0.6,0.05,100,1,0,1744374684,1744374684,1),(6,'金牌代理',5000,0,2000,0,6,0.85,0.65,0.65,0.05,100,1,0,1744374684,1744374684,1);
/*!40000 ALTER TABLE `agent_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_member`
--

DROP TABLE IF EXISTS `agent_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_member` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `member_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '会员id',
  `parent_id1` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '上级id',
  `parent_id2` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '上上级id',
  `brokerage_total` double NOT NULL DEFAULT '0' COMMENT '合计佣金',
  `brokerage_usable` double NOT NULL DEFAULT '0' COMMENT '可用佣金',
  `brokerage_freeze` double NOT NULL DEFAULT '0' COMMENT '冻结佣金',
  `brokerage_cashed` double NOT NULL DEFAULT '0' COMMENT '已提现佣金',
  `level` bigint NOT NULL DEFAULT '0' COMMENT '代理等级',
  `lock_level` bigint NOT NULL DEFAULT '0' COMMENT '是否锁定等级{0:否,1:是}',
  `performance_total` double NOT NULL DEFAULT '0' COMMENT '合计业绩',
  `recharge_total` double NOT NULL DEFAULT '0' COMMENT '合计充值',
  `invite_code` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '邀请码',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invite_code_name` (`invite_code`),
  KEY `idx_agent_member_member_id` (`member_id`),
  KEY `idx_agent_member_parent_id1` (`parent_id1`),
  KEY `idx_agent_member_parent_id2` (`parent_id2`),
  KEY `idx_agent_member_level` (`level`),
  KEY `idx_agent_member_lock_level` (`lock_level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_member`
--

LOCK TABLES `agent_member` WRITE;
/*!40000 ALTER TABLE `agent_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `agent_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_withdraw`
--

DROP TABLE IF EXISTS `agent_withdraw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_withdraw` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `member_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '会员id',
  `agent_level_id` bigint NOT NULL DEFAULT '0' COMMENT '代理等级id',
  `agent_level_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '代理等级名称',
  `title` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
  `amount1` double NOT NULL DEFAULT '0' COMMENT '变化前金额',
  `amount2` double NOT NULL DEFAULT '0' COMMENT '变化的金额',
  `amount3` double NOT NULL DEFAULT '0' COMMENT '变化后金额',
  `withdraw_address` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '提现地址',
  `withdraw_fee` double NOT NULL DEFAULT '0' COMMENT '手续费',
  `withdraw_fees` double NOT NULL DEFAULT '0' COMMENT '手续费金额',
  `withdraw_amount` double NOT NULL DEFAULT '0' COMMENT '实付金额',
  `status` bigint NOT NULL DEFAULT '0' COMMENT '提现状态{100:待受理,200:处理中,300:已完成,400:已关闭}',
  `status_desc` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '提现状态描述',
  `ver` bigint NOT NULL DEFAULT '0' COMMENT '版本号',
  `attach` text COLLATE utf8mb4_unicode_ci COMMENT '附加说明',
  `ip` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '提现ip',
  `ip_address` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '提现ip地址',
  `exchange_rate` double NOT NULL DEFAULT '0' COMMENT '汇率',
  `amount21` double NOT NULL DEFAULT '0' COMMENT '相对于amount2的金额',
  `withdraw_at` bigint NOT NULL DEFAULT '0' COMMENT '提现时间',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `receive_agency` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'wallet',
  `receive_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `receive_account` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_agent_withdraw_ver` (`ver`),
  KEY `idx_agent_withdraw_member_id` (`member_id`),
  KEY `idx_agent_withdraw_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_withdraw`
--

LOCK TABLES `agent_withdraw` WRITE;
/*!40000 ALTER TABLE `agent_withdraw` DISABLE KEYS */;
/*!40000 ALTER TABLE `agent_withdraw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_withdraw_log`
--

DROP TABLE IF EXISTS `agent_withdraw_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_withdraw_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `withdraw_id` bigint NOT NULL DEFAULT '0' COMMENT '提现id',
  `customer_id` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '客服id',
  `customer_behavior` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '客服行为',
  `status1` bigint NOT NULL DEFAULT '0' COMMENT '操作前的提现状态{100:待受理,200:处理中,300:已完成,400:已关闭}',
  `status2` bigint NOT NULL DEFAULT '0' COMMENT '操作后的提现状态{100:待受理,200:处理中,300:已完成,400:已关闭}',
  `ip` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '操作ip',
  `ip_address` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '操作ip地址',
  `remark` text COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_agent_withdraw_log_status1` (`status1`),
  KEY `idx_agent_withdraw_log_status2` (`status2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_withdraw_log`
--

LOCK TABLES `agent_withdraw_log` WRITE;
/*!40000 ALTER TABLE `agent_withdraw_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `agent_withdraw_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `album`
--

DROP TABLE IF EXISTS `album`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `album` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
  `surface_plot` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '封面地址',
  `recommend` bigint NOT NULL COMMENT '是否推荐 1是 2否',
  `introduce` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '简介',
  `popularity_day` bigint NOT NULL COMMENT '日人气',
  `popularity_week` bigint NOT NULL COMMENT '周人气',
  `popularity_month` bigint NOT NULL COMMENT '月人气',
  `popularity_sum` bigint NOT NULL COMMENT '总人气',
  `note` text COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  PRIMARY KEY (`id`),
  KEY `idx_album_site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album`
--

LOCK TABLES `album` WRITE;
/*!40000 ALTER TABLE `album` DISABLE KEYS */;
/*!40000 ALTER TABLE `album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `album_video`
--

DROP TABLE IF EXISTS `album_video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `album_video` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `album_id` bigint NOT NULL COMMENT '名人id',
  `videos_id` bigint DEFAULT NULL COMMENT '影片id',
  `create_at` bigint DEFAULT NULL,
  `update_at` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_album_video_videos_id` (`videos_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album_video`
--

LOCK TABLES `album_video` WRITE;
/*!40000 ALTER TABLE `album_video` DISABLE KEYS */;
/*!40000 ALTER TABLE `album_video` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `android_versions`
--

DROP TABLE IF EXISTS `android_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `android_versions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `version_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '版本号',
  `apk_code` int unsigned DEFAULT NULL COMMENT '唯一标识',
  `file_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '文件路劲',
  `cfg_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '配置路劲',
  `status` bigint DEFAULT NULL COMMENT '状态0-未发布，1-已发布',
  `channel_id` bigint DEFAULT NULL COMMENT '渠道id',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `android_versions`
--

LOCK TABLES `android_versions` WRITE;
/*!40000 ALTER TABLE `android_versions` DISABLE KEYS */;
/*!40000 ALTER TABLE `android_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app`
--

DROP TABLE IF EXISTS `app`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app_id` bigint NOT NULL DEFAULT '0' COMMENT '超管返回',
  `version_app_id` bigint NOT NULL DEFAULT '0' COMMENT '超管返回',
  `site_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'App名称',
  `channel_id` bigint NOT NULL DEFAULT '0' COMMENT '渠道id',
  `version` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'app版本',
  `current_version` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'app版本',
  `icon` text COLLATE utf8mb4_unicode_ci COMMENT '图表地址',
  `domain` text COLLATE utf8mb4_unicode_ci COMMENT '内置域名',
  `visit_domain` text COLLATE utf8mb4_unicode_ci COMMENT '访问域名',
  `state` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NORMAL' COMMENT '状态',
  `os` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '应用所属操作系统',
  `pack_info` text COLLATE utf8mb4_unicode_ci COMMENT '打包信息',
  `publish_at` bigint NOT NULL DEFAULT '0' COMMENT '发布时间',
  `pack_at` bigint NOT NULL DEFAULT '0' COMMENT '打包开始时间',
  `download_url` text COLLATE utf8mb4_unicode_ci COMMENT '下载地址',
  `latest_download_url` text COLLATE utf8mb4_unicode_ci COMMENT '最新下载地址(后台使用)',
  `supt_username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '超管登录用户名',
  `slogan` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `app_code` int unsigned DEFAULT NULL COMMENT '唯一标识,用于升级',
  `current_app_code` int unsigned DEFAULT NULL COMMENT '当前版本唯一标识,用于升级',
  `next_app_id` bigint NOT NULL DEFAULT '0',
  `next_app_packing_at` bigint NOT NULL DEFAULT '0',
  `next_app_release_at` bigint NOT NULL DEFAULT '0',
  `next_app_state` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `next_app_update_content` longtext COLLATE utf8mb4_unicode_ci,
  `update_content` longtext COLLATE utf8mb4_unicode_ci,
  `next_app_version` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `logo` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'app Log',
  `package_args` text COLLATE utf8mb4_unicode_ci COMMENT '打包参数',
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  `download_process` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '下载进度',
  `download_latest_process` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '下载最新版本进度',
  `download_message` text COLLATE utf8mb4_unicode_ci COMMENT '下载错误信息',
  `download_latest_message` text COLLATE utf8mb4_unicode_ci COMMENT '下载最新版错误信息',
  `custom_package_args` longtext COLLATE utf8mb4_unicode_ci COMMENT '自定义打包参数',
  `custom_package_args_json` longtext COLLATE utf8mb4_unicode_ci COMMENT '自定义打包(前端使用)',
  `download_type` int NOT NULL DEFAULT '0' COMMENT '下载方式0-默认 1-自定义',
  `custom_download_url` text COLLATE utf8mb4_unicode_ci COMMENT '自定义下载地址',
  `publish_title` text COLLATE utf8mb4_unicode_ci COMMENT '发布标题',
  `publish_content` text COLLATE utf8mb4_unicode_ci COMMENT '发布内容',
  `force_upgrade` int NOT NULL DEFAULT '1' COMMENT '是否强制更新',
  `upgrade_type` text COLLATE utf8mb4_unicode_ci COMMENT '升级类型 NORMAL:普通升级 MANDATORY:强制升级',
  PRIMARY KEY (`id`),
  KEY `idx_app_supt_user_name` (`supt_username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app`
--

LOCK TABLES `app` WRITE;
/*!40000 ALTER TABLE `app` DISABLE KEYS */;
/*!40000 ALTER TABLE `app` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_sites`
--

DROP TABLE IF EXISTS `app_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_sites` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app_id` bigint NOT NULL DEFAULT '0' COMMENT '超管返回',
  `site_id` bigint NOT NULL DEFAULT '0' COMMENT '站点id',
  `channel_id` bigint NOT NULL DEFAULT '0' COMMENT '渠道id',
  `channel_code` varchar(191) NOT NULL DEFAULT '' COMMENT '唯一编码',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_sites`
--

LOCK TABLES `app_sites` WRITE;
/*!40000 ALTER TABLE `app_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_use_channel`
--

DROP TABLE IF EXISTS `app_use_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_use_channel` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `os` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '应用所属操作系统',
  `app_id` bigint NOT NULL DEFAULT '0' COMMENT '超管返回',
  `channel_id` bigint NOT NULL DEFAULT '0' COMMENT '渠道id',
  `supt_username` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '超管登录用户名',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_app_use_channel_supt_user_name` (`supt_username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_use_channel`
--

LOCK TABLES `app_use_channel` WRITE;
/*!40000 ALTER TABLE `app_use_channel` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_use_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `article_celebrities`
--

DROP TABLE IF EXISTS `article_celebrities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `article_celebrities` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `celebrity_id` bigint DEFAULT '0' COMMENT '名人id',
  `article_id` bigint DEFAULT '0' COMMENT '文章id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article_celebrities`
--

LOCK TABLES `article_celebrities` WRITE;
/*!40000 ALTER TABLE `article_celebrities` DISABLE KEYS */;
/*!40000 ALTER TABLE `article_celebrities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `articles` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `category_pid` bigint NOT NULL COMMENT '分类一级id',
  `category_child_id` bigint NOT NULL COMMENT '分类二级id',
  `content` longtext COLLATE utf8mb4_unicode_ci COMMENT '内容',
  `surface_plot` text COLLATE utf8mb4_unicode_ci COMMENT '封面图',
  `status` bigint NOT NULL COMMENT '状态',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `introduce` text COLLATE utf8mb4_unicode_ci COMMENT '简介',
  `origin` text COLLATE utf8mb4_unicode_ci COMMENT '来源',
  `popularity` bigint NOT NULL DEFAULT '0' COMMENT '人气',
  `is_hot` bigint NOT NULL DEFAULT '0' COMMENT '热门，1-是，0-否',
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  PRIMARY KEY (`id`),
  KEY `idx_category_cid` (`category_child_id`),
  KEY `idx_category_pid` (`category_pid`),
  KEY `idx_articles_site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles`
--

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auto_reply`
--

DROP TABLE IF EXISTS `auto_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auto_reply` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL COMMENT '用户id',
  `sort` bigint DEFAULT '0',
  `content` text COLLATE utf8mb4_unicode_ci COMMENT '内容',
  `status` bigint NOT NULL DEFAULT '1',
  `timeout` bigint DEFAULT NULL COMMENT '超时未响应-分钟',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auto_reply`
--

LOCK TABLES `auto_reply` WRITE;
/*!40000 ALTER TABLE `auto_reply` DISABLE KEYS */;
/*!40000 ALTER TABLE `auto_reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auto_service`
--

DROP TABLE IF EXISTS `auto_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auto_service` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL COMMENT '用户id',
  `sort` bigint DEFAULT '0' COMMENT '排序',
  `content` text COLLATE utf8mb4_unicode_ci COMMENT '内容',
  `trigger_event` bigint DEFAULT NULL COMMENT '触发事件1-初次连接，2-转接, 3-服务结束',
  `status` bigint NOT NULL DEFAULT '1',
  `service_enable` bigint NOT NULL DEFAULT '0',
  `client_enable` bigint NOT NULL DEFAULT '0',
  `timeout` bigint DEFAULT NULL COMMENT '超时未响应-分钟',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auto_service`
--

LOCK TABLES `auto_service` WRITE;
/*!40000 ALTER TABLE `auto_service` DISABLE KEYS */;
/*!40000 ALTER TABLE `auto_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `barrage`
--

DROP TABLE IF EXISTS `barrage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `barrage` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '弹幕唯一标识',
  `site_id` bigint NOT NULL,
  `member_id` varchar(100) NOT NULL DEFAULT '' COMMENT '弹幕发送id',
  `video_id` bigint NOT NULL,
  `resource_name` varchar(191) NOT NULL DEFAULT '' COMMENT '视频',
  `play_line_id` bigint NOT NULL,
  `relative_time` int NOT NULL COMMENT '弹幕展示时间-单位秒',
  `send_time` int NOT NULL COMMENT '弹幕发送时间-单位秒',
  `send_date` varchar(20) NOT NULL COMMENT '弹幕的发送日期',
  `content` text NOT NULL COMMENT '弹幕内容',
  `color` varchar(20) DEFAULT NULL COMMENT '颜色',
  `agree` int NOT NULL COMMENT '点赞数',
  `ip` varchar(255) NOT NULL DEFAULT '' COMMENT '发送弹幕者IP',
  `status` tinyint NOT NULL COMMENT '1未审核2审核通过3审核未通过',
  `reject_reason` varchar(191) DEFAULT NULL COMMENT '审核未通过的原因',
  `create_at` bigint DEFAULT NULL,
  `update_at` bigint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='站点弹幕内容信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `barrage`
--

LOCK TABLES `barrage` WRITE;
/*!40000 ALTER TABLE `barrage` DISABLE KEYS */;
/*!40000 ALTER TABLE `barrage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `barrage_config`
--

DROP TABLE IF EXISTS `barrage_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `barrage_config` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '弹幕配置唯一标识',
  `site_id` bigint NOT NULL,
  `open` smallint NOT NULL DEFAULT '0' COMMENT '弹幕是否开启0为关闭1为开启',
  `config_json` text COMMENT '配置json',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='站点弹幕配置信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `barrage_config`
--

LOCK TABLES `barrage_config` WRITE;
/*!40000 ALTER TABLE `barrage_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `barrage_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `broadcast_resource`
--

DROP TABLE IF EXISTS `broadcast_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `broadcast_resource` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `host` text COLLATE utf8mb4_unicode_ci COMMENT '服务器地址',
  `path` text COLLATE utf8mb4_unicode_ci,
  `create_at` bigint NOT NULL,
  `local_ip` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `broadcast_resource`
--

LOCK TABLES `broadcast_resource` WRITE;
/*!40000 ALTER TABLE `broadcast_resource` DISABLE KEYS */;
/*!40000 ALTER TABLE `broadcast_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `browses`
--

DROP TABLE IF EXISTS `browses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `browses` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `member_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '会员uuid',
  `video_id` bigint NOT NULL DEFAULT '0' COMMENT '影片id',
  `resource_id` bigint NOT NULL DEFAULT '0' COMMENT '资源id',
  `type` bigint NOT NULL DEFAULT '0' COMMENT '类型,1-视频 2-文章 ',
  `duration` bigint NOT NULL DEFAULT '0' COMMENT '影片观看时长',
  `progress` bigint NOT NULL DEFAULT '0' COMMENT '影片进度',
  `browse_date` bigint NOT NULL DEFAULT '0' COMMENT '日期',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  `jump_url` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板跳转地址',
  `line_id` bigint DEFAULT '0' COMMENT '线路id',
  `parameter` text COLLATE utf8mb4_unicode_ci COMMENT '备用字段',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_member_v_browse` (`member_id`,`video_id`,`type`),
  KEY `idx_video_id` (`video_id`),
  KEY `idx_browses_site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `browses`
--

LOCK TABLES `browses` WRITE;
/*!40000 ALTER TABLE `browses` DISABLE KEYS */;
/*!40000 ALTER TABLE `browses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cami`
--

DROP TABLE IF EXISTS `cami`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cami` (
  `account` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '卡号',
  `password` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '密码',
  `type` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服务类别',
  `bid` bigint DEFAULT NULL COMMENT '绑定服务ID',
  `money` bigint DEFAULT NULL COMMENT '自定义金额，单位分',
  `uid` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '绑定使用者账号ID',
  `status` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '状态',
  `expired_at` bigint DEFAULT NULL COMMENT '激活有效期时间戳',
  `used_at` bigint DEFAULT NULL COMMENT '激活时间戳',
  `created_at` bigint DEFAULT NULL COMMENT '创建时间戳',
  `updated_at` bigint DEFAULT NULL COMMENT '最近更新时间戳',
  `site_id` int NOT NULL DEFAULT '0',
  `start_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`account`),
  UNIQUE KEY `idxCami_account` (`account`),
  KEY `idxCami_status_type` (`status`,`type`),
  KEY `idxCami_type_bid_status` (`type`,`bid`,`status`),
  KEY `idxCami_type_status` (`type`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡密表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cami`
--

LOCK TABLES `cami` WRITE;
/*!40000 ALTER TABLE `cami` DISABLE KEYS */;
/*!40000 ALTER TABLE `cami` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `parent_id` bigint NOT NULL COMMENT '父id',
  `type` bigint NOT NULL COMMENT '类型 1影片 2名人 3文章',
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '分类名称',
  `sort` bigint NOT NULL COMMENT '排序',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `is_vertical` int NOT NULL DEFAULT '0' COMMENT '是否是竖屏，1-是，0-否',
  `is_font` int NOT NULL DEFAULT '0' COMMENT '是否是纯文字，1-是，0-否',
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  `status` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idxCategory_siteID_status_type` (`site_id`,`status`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,0,1,'电影',1,1744374684,1744374684,0,0,1,1),(2,0,1,'电视剧',2,1744374684,1744374684,0,0,1,1),(3,0,1,'综艺',3,1744374684,1744374684,0,0,1,1),(4,0,1,'动漫',4,1744374684,1744374684,0,0,1,1),(5,0,2,'演员',0,1744374684,1744374684,0,0,1,1),(6,0,2,'导演',0,1744374684,1744374684,0,0,1,1),(7,0,2,'作家',0,1744374684,1744374684,0,0,1,1),(8,0,2,'编剧',0,1744374684,1744374684,0,0,1,1),(9,1,1,'动作片',1,1744374684,1744374684,0,0,1,1),(10,1,1,'喜剧片',2,1744374684,1744374684,0,0,1,1),(11,1,1,'爱情片',3,1744374684,1744374684,0,0,1,1),(12,1,1,'恐怖片',4,1744374684,1744374684,0,0,1,1),(13,1,1,'剧情片',5,1744374684,1744374684,0,0,1,1),(14,1,1,'科幻片',6,1744374684,1744374684,0,0,1,1),(15,1,1,'惊悚片',7,1744374684,1744374684,0,0,1,1),(16,1,1,'奇幻片',8,1744374684,1744374684,0,0,1,1),(17,1,1,'动画片',9,1744374684,1744374684,0,0,1,1),(18,1,1,'悬疑片',10,1744374684,1744374684,0,0,1,1),(19,1,1,'冒险片',11,1744374684,1744374684,0,0,1,1),(20,1,1,'纪录片',12,1744374684,1744374684,0,0,1,1),(21,1,1,'战争片',13,1744374684,1744374684,0,0,1,1),(22,2,1,'国产剧',1,1744374684,1744374684,0,0,1,1),(23,2,1,'香港剧',2,1744374684,1744374684,0,0,1,1),(24,2,1,'台湾剧',3,1744374684,1744374684,0,0,1,1),(25,2,1,'欧美剧',4,1744374684,1744374684,0,0,1,1),(26,2,1,'日本剧',5,1744374684,1744374684,0,0,1,1),(27,2,1,'韩国剧',6,1744374684,1744374684,0,0,1,1),(28,2,1,'泰国剧',7,1744374684,1744374684,0,0,1,1),(29,2,1,'海外剧',8,1744374684,1744374684,0,0,1,1),(30,3,1,'大陆综艺',1,1744374684,1744374684,0,0,1,1),(31,3,1,'港台综艺',2,1744374684,1744374684,0,0,1,1),(32,3,1,'日韩综艺',3,1744374684,1744374684,0,0,1,1),(33,3,1,'欧美综艺',4,1744374684,1744374684,0,0,1,1),(34,3,1,'海外综艺',5,1744374684,1744374684,0,0,1,1),(35,4,1,'国产动漫',1,1744374684,1744374684,0,0,1,1),(36,4,1,'日本动漫',2,1744374684,1744374684,0,0,1,1),(37,4,1,'欧美动漫',3,1744374684,1744374684,0,0,1,1),(38,4,1,'海外动漫',4,1744374684,1744374684,0,0,1,1);
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_filter`
--

DROP TABLE IF EXISTS `category_filter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category_filter` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `category_id` bigint DEFAULT NULL COMMENT '分类一级id',
  `filter_id` bigint DEFAULT NULL COMMENT '筛选组id',
  `type` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '类型-年份，语言，地区',
  `sort` bigint DEFAULT NULL,
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  PRIMARY KEY (`id`),
  KEY `idx_category_id` (`category_id`),
  KEY `idx_category_filter_site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_filter`
--

LOCK TABLES `category_filter` WRITE;
/*!40000 ALTER TABLE `category_filter` DISABLE KEYS */;
/*!40000 ALTER TABLE `category_filter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `celebrity`
--

DROP TABLE IF EXISTS `celebrity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `celebrity` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `chinese_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '中文姓名',
  `category_pid` bigint NOT NULL COMMENT '分类一级id',
  `category_child_id` bigint NOT NULL COMMENT '分类二级id',
  `head_img` text COLLATE utf8mb4_unicode_ci COMMENT '头像',
  `sex` bigint NOT NULL DEFAULT '3' COMMENT '性别 1男 2女',
  `recommend` bigint NOT NULL COMMENT '是否推荐 1是 2否',
  `nationality` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '国籍',
  `profession` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '职业',
  `master_work` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '代表作',
  `introduce` text COLLATE utf8mb4_unicode_ci COMMENT '简介',
  `english_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '英文姓名',
  `nick_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '昵称/别名',
  `height` bigint NOT NULL COMMENT '身高(cm)',
  `weight` bigint NOT NULL COMMENT '体重(kg)',
  `birthday` bigint NOT NULL COMMENT '生日',
  `celebrity_like` text COLLATE utf8mb4_unicode_ci COMMENT '爱好',
  `popularity` bigint NOT NULL COMMENT '人气',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '详情',
  `star_sign` text COLLATE utf8mb4_unicode_ci COMMENT '星座',
  `blood_type` text COLLATE utf8mb4_unicode_ci COMMENT '血型',
  `school` text COLLATE utf8mb4_unicode_ci COMMENT '学校',
  `native_place` text COLLATE utf8mb4_unicode_ci COMMENT '籍贯(出生地)',
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  `height_chinese` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '身高中文表述',
  `weight_chinese` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '体重中文表述',
  `birthday_chinese` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '生日中文表述',
  PRIMARY KEY (`id`),
  KEY `idx_category_cid` (`category_child_id`),
  KEY `idx_name_en` (`english_name`),
  KEY `idx_name` (`chinese_name`),
  KEY `idx_category_pid` (`category_pid`),
  KEY `idx_celebrity_site_id` (`site_id`),
  KEY `celebrity_chinese_name` (`chinese_name`,`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `celebrity`
--

LOCK TABLES `celebrity` WRITE;
/*!40000 ALTER TABLE `celebrity` DISABLE KEYS */;
/*!40000 ALTER TABLE `celebrity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `celebrity_category`
--

DROP TABLE IF EXISTS `celebrity_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `celebrity_category` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `category_pid` bigint DEFAULT '0' COMMENT '分类id',
  `category_id` bigint DEFAULT '0' COMMENT '分类id',
  `celebrity_id` bigint DEFAULT '0' COMMENT '名人id',
  `create_at` bigint NOT NULL DEFAULT '0',
  `update_at` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_cele_p_id` (`category_pid`),
  KEY `idx_cele_cate_id` (`category_id`),
  KEY `celebrity_category_celebrity_id_index` (`celebrity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `celebrity_category`
--

LOCK TABLES `celebrity_category` WRITE;
/*!40000 ALTER TABLE `celebrity_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `celebrity_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `celebrity_data`
--

DROP TABLE IF EXISTS `celebrity_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `celebrity_data` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `celebrity_id` bigint DEFAULT NULL COMMENT '名人id',
  `videos_id` bigint DEFAULT NULL COMMENT '影片id',
  `create_at` bigint DEFAULT NULL,
  `update_at` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_celebrity_data_celebrity_id` (`celebrity_id`),
  KEY `idx_celebrity_data_videos_id` (`videos_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `celebrity_data`
--

LOCK TABLES `celebrity_data` WRITE;
/*!40000 ALTER TABLE `celebrity_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `celebrity_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channels`
--

DROP TABLE IF EXISTS `channels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `channels` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '渠道名称',
  `channel_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '唯一编码',
  `state` bigint DEFAULT NULL COMMENT '状态 1启用 2禁用',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `site_id` int NOT NULL DEFAULT '0' COMMENT '站点id',
  PRIMARY KEY (`id`),
  KEY `idx_channel_id` (`channel_code`),
  KEY `channels_site_id_index` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channels`
--

LOCK TABLES `channels` WRITE;
/*!40000 ALTER TABLE `channels` DISABLE KEYS */;
/*!40000 ALTER TABLE `channels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chapter`
--

DROP TABLE IF EXISTS `chapter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chapter` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL DEFAULT '1' COMMENT '站点id',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '标题',
  `words_number` bigint NOT NULL DEFAULT '0' COMMENT '字数',
  `number` bigint NOT NULL DEFAULT '0' COMMENT '章节号',
  `novel_id` bigint NOT NULL DEFAULT '0' COMMENT '小说id',
  `content` text NOT NULL COMMENT '内容',
  `volume` varchar(50) NOT NULL DEFAULT '' COMMENT '卷名',
  `release_date` bigint NOT NULL DEFAULT '0' COMMENT '发布日期',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='小说章节';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chapter`
--

LOCK TABLES `chapter` WRITE;
/*!40000 ALTER TABLE `chapter` DISABLE KEYS */;
/*!40000 ALTER TABLE `chapter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collection`
--

DROP TABLE IF EXISTS `collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collection` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `data_method` bigint NOT NULL DEFAULT '1' COMMENT '数据类型:1JSON 2XML',
  `data_type` bigint NOT NULL DEFAULT '1' COMMENT '数据类型:1视频 2影人',
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '地址',
  `param` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '参数',
  `desc` text COLLATE utf8mb4_unicode_ci COMMENT '说明',
  `charging_mode` bigint NOT NULL DEFAULT '1' COMMENT '收费模式 1免费 2vip免费 3金币点播',
  `data_handle` bigint NOT NULL DEFAULT '1' COMMENT '数据操作 1新增+更新 2新增 3更新',
  `log_id` bigint NOT NULL DEFAULT '0' COMMENT '请求日志id',
  `sr_id` bigint DEFAULT '0' COMMENT '超管平台资源id',
  `status` bigint DEFAULT '1' COMMENT 'COMMENT',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `cms` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '适用系统:sda-精品 mc-苹果cms mc10-苹果10 fei4-飞飞4 sea-海洋cms ct-赤兔 zp-赞片 max-马克思',
  `match_player` tinyint(1) DEFAULT NULL COMMENT '是否匹配资源播放器',
  `use_parse` int NOT NULL DEFAULT '0' COMMENT '是否启用解析,1-是，2-否',
  `parse_address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '解析地址，视频播放地址',
  `tags` text COLLATE utf8mb4_unicode_ci COMMENT '来源',
  `color` text COLLATE utf8mb4_unicode_ci,
  `bold` int NOT NULL DEFAULT '0',
  `sort` int NOT NULL DEFAULT '99',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collection`
--

LOCK TABLES `collection` WRITE;
/*!40000 ALTER TABLE `collection` DISABLE KEYS */;
INSERT INTO `collection` VALUES (1,'索尼资源网',2,1,'https://suoniapi.com/api.php/provide/vod/from/snm3u8/at/xml/','','高清画质,更新快,秒播,国内线路!永久免费的资源站！',1,1,0,3,1,1744374475,1744374475,'mc10',0,0,'','','#FF4500',0,1),(2,'闪电资源网',2,1,'https://xsd.sdzyapi.com/api.php/provide/vod/from/sdm3u8/at/xml','','采用国内CDN加速，速度快到无法想象！',1,1,0,6,1,1744374475,1744374475,'mc10',0,0,'','','#6D20F2',0,2),(3,'最大资源网',2,1,'https://api.zuidapi.com/api.php/provide/vod/from/zuidam3u8/at/xml','','快速更新，稳定播放！',1,1,0,7,1,1744374475,1744374475,'mc10',0,0,'','','#A804C9',0,3),(4,'暴风资源网',2,1,'https://bfzyapi.com/api.php/provide/vod/at/xml','','无水印，三网直连，秒拉秒播',1,1,0,8,1,1744374475,1744374475,'mc10',0,0,'','','#C71585',0,4),(5,'黑木耳资源',1,1,'https://json.heimuer.tv/api.php/provide/vod/?ac=list','','真·高清 真·无广告',1,1,0,10,1,1744374475,1744374475,'mc10',0,0,'','','#A71010',0,5),(6,'淘片资源网',2,1,'https://taopianapi.com/cjapi/sda/vod/xml/m3u8.html','','每日海量更新,T级带宽,极速播放',1,1,0,1,1,1744374475,1744374475,'sda',0,0,'','','#006AFF',0,6);
/*!40000 ALTER TABLE `collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collection_category`
--

DROP TABLE IF EXISTS `collection_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collection_category` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `resource_id` bigint NOT NULL COMMENT '资源id',
  `class_id` bigint NOT NULL COMMENT '采集资源分类id',
  `class_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '采集资源分类',
  `category_id` bigint NOT NULL COMMENT '系统分类id',
  `category_child_id` bigint DEFAULT '0' COMMENT '系统分类id',
  `charging_mode` bigint NOT NULL DEFAULT '1' COMMENT '收费模式 1免费 2vip免费 3金币点播',
  `gold` bigint NOT NULL DEFAULT '0' COMMENT '金币点播值',
  `buy_mode` bigint NOT NULL DEFAULT '1' COMMENT '购买模式 1按部 2按集',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  PRIMARY KEY (`id`),
  KEY `collection_category_site_id_class_id_index` (`site_id`,`class_id`,`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collection_category`
--

LOCK TABLES `collection_category` WRITE;
/*!40000 ALTER TABLE `collection_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `collection_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collection_config`
--

DROP TABLE IF EXISTS `collection_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collection_config` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sync_cover` tinyint(1) NOT NULL,
  `time_use` bigint NOT NULL,
  `rand_hot` tinyint(1) NOT NULL,
  `hot_min` bigint NOT NULL,
  `hot_max` bigint NOT NULL,
  `rule` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `update_rule` bigint NOT NULL,
  `update_column` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `update_at` bigint NOT NULL,
  `create_at` bigint NOT NULL,
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  `douban_score_min` bigint NOT NULL DEFAULT '10',
  `douban_score_max` bigint NOT NULL DEFAULT '100',
  `rand_douban_score` bigint DEFAULT '0',
  `save_type` int NOT NULL DEFAULT '0' COMMENT '1-保存本地，2-ftp',
  `save_ftp` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ftp信息',
  `data_type` int NOT NULL DEFAULT '1' COMMENT '1视频 2影人 3-图文',
  `save_celebrity` int NOT NULL DEFAULT '1' COMMENT '是否保存影人 1-保存，2-不保存',
  `sensitive` longtext COLLATE utf8mb4_unicode_ci COMMENT '敏感词逗号分隔',
  `synonym_open` int NOT NULL DEFAULT '2' COMMENT '开启同义词替换：1-替换，2-不替换',
  `synonyms` longtext COLLATE utf8mb4_unicode_ci COMMENT '同义词',
  PRIMARY KEY (`id`),
  UNIQUE KEY `collection_config_data_type` (`data_type`),
  KEY `idx_collection_config_site_id` (`site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collection_config`
--

LOCK TABLES `collection_config` WRITE;
/*!40000 ALTER TABLE `collection_config` DISABLE KEYS */;
INSERT INTO `collection_config` VALUES (1,0,1,0,0,100,'name,category',1,'category,introduce,description,head_img',1744374475,1744374475,0,0,100,0,1,'',2,1,'',2,''),(2,0,1,0,0,100,'title,category_child_id',1,'status,update_at,playline,note',1744374475,1744374475,0,0,100,0,1,'',1,1,'',2,''),(3,0,1,0,0,100,'name,category',1,'category,content,surface_plot,introduce',1744374475,1744374475,0,0,100,0,1,'',3,1,'',2,'');
/*!40000 ALTER TABLE `collection_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collection_log_record`
--

DROP TABLE IF EXISTS `collection_log_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collection_log_record` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `resource_id` bigint NOT NULL COMMENT '资源id',
  `log_id` bigint NOT NULL COMMENT '请求id',
  `title` text COLLATE utf8mb4_unicode_ci,
  `page` bigint NOT NULL DEFAULT '0' COMMENT '采集页码',
  `message` text COLLATE utf8mb4_unicode_ci COMMENT '消息',
  `create_at` bigint NOT NULL DEFAULT '0',
  `update_at` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collection_log_record`
--

LOCK TABLES `collection_log_record` WRITE;
/*!40000 ALTER TABLE `collection_log_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `collection_log_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collection_req_log`
--

DROP TABLE IF EXISTS `collection_req_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collection_req_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `resource_id` bigint NOT NULL COMMENT '资源id',
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '资源名称',
  `data_type` bigint NOT NULL DEFAULT '1' COMMENT '数据类型:1视频 2影人',
  `op` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '采集范围',
  `url` text COLLATE utf8mb4_unicode_ci COMMENT '请求地址',
  `total` bigint NOT NULL DEFAULT '0' COMMENT '采集总条数',
  `finish_total` bigint NOT NULL DEFAULT '0' COMMENT '采集完成条数',
  `page_total` bigint NOT NULL DEFAULT '0' COMMENT '页码总数',
  `current_page` bigint NOT NULL DEFAULT '0' COMMENT '正在采集页码',
  `page_size` bigint NOT NULL DEFAULT '0' COMMENT '正在采集页码',
  `status` bigint NOT NULL DEFAULT '0' COMMENT '状态,0-未完成，1-已完成',
  `message` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '消息',
  `create_at` bigint NOT NULL DEFAULT '0',
  `update_at` bigint NOT NULL DEFAULT '0',
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  `execution_total` bigint NOT NULL DEFAULT '0' COMMENT '采集执行条数',
  PRIMARY KEY (`id`),
  KEY `idx_colog_site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collection_req_log`
--

LOCK TABLES `collection_req_log` WRITE;
/*!40000 ALTER TABLE `collection_req_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `collection_req_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collection_task`
--

DROP TABLE IF EXISTS `collection_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collection_task` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `collection_id` bigint NOT NULL DEFAULT '0' COMMENT '采集库id',
  `type` smallint NOT NULL DEFAULT '1' COMMENT '采集方式:1当天 2本周 3本月 4全部',
  `interval` bigint NOT NULL DEFAULT '1' COMMENT '间隔时间（单位分钟）',
  `status` smallint NOT NULL DEFAULT '1' COMMENT '状态 1启用 2停用',
  `last_collection_time` bigint NOT NULL DEFAULT '0' COMMENT '上次采集时间',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `task_id` bigint NOT NULL DEFAULT '0' COMMENT '定时任务id',
  `trigger_type` bigint DEFAULT '1' COMMENT '触发类型1-间隔,2-定时',
  `spec` text COLLATE utf8mb4_unicode_ci COMMENT '定时',
  `tasks` text COLLATE utf8mb4_unicode_ci COMMENT '定时任务信息',
  PRIMARY KEY (`id`),
  KEY `idx_collection_id` (`collection_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collection_task`
--

LOCK TABLES `collection_task` WRITE;
/*!40000 ALTER TABLE `collection_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `collection_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collection_video_images`
--

DROP TABLE IF EXISTS `collection_video_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collection_video_images` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `resource_id` bigint NOT NULL DEFAULT '0' COMMENT '资源id',
  `log_id` bigint NOT NULL DEFAULT '0' COMMENT '请求id',
  `video_id` bigint NOT NULL DEFAULT '0',
  `surface_plot` text COLLATE utf8mb4_unicode_ci COMMENT '影片封面图',
  `cycle_img` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '轮播图片',
  `horizontal_poster` text COLLATE utf8mb4_unicode_ci COMMENT '横屏海报',
  `vertical_poster` text COLLATE utf8mb4_unicode_ci COMMENT '竖屏海报',
  `original_surface_plot` text COLLATE utf8mb4_unicode_ci COMMENT '原始影片封面图',
  `original_cycle_img` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '原始轮播图片',
  `original_horizontal_poster` text COLLATE utf8mb4_unicode_ci COMMENT '原始横屏海报',
  `original_vertical_poster` text COLLATE utf8mb4_unicode_ci COMMENT '原始竖屏海报',
  `screenshot` text COLLATE utf8mb4_unicode_ci COMMENT '截屏',
  `original_screenshot` text COLLATE utf8mb4_unicode_ci COMMENT '截屏',
  `status` bigint DEFAULT '0' COMMENT '下载状态0-未下载，1-已下载',
  `create_at` bigint NOT NULL DEFAULT '0',
  `update_at` bigint NOT NULL DEFAULT '0',
  `video_list` text COLLATE utf8mb4_unicode_ci COMMENT '记录多个视频，多站点采集',
  PRIMARY KEY (`id`),
  KEY `idx_collection_video_images_video_id` (`video_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collection_video_images`
--

LOCK TABLES `collection_video_images` WRITE;
/*!40000 ALTER TABLE `collection_video_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `collection_video_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment_config`
--

DROP TABLE IF EXISTS `comment_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment_config` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `open` tinyint(1) NOT NULL,
  `need_login` tinyint(1) NOT NULL,
  `need_audit` tinyint(1) NOT NULL,
  `sensitive_words` text COLLATE utf8mb4_unicode_ci,
  `max_comment_num` bigint NOT NULL,
  `interval` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `create_at` bigint NOT NULL,
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment_config`
--

LOCK TABLES `comment_config` WRITE;
/*!40000 ALTER TABLE `comment_config` DISABLE KEYS */;
INSERT INTO `comment_config` VALUES (1,0,0,0,'',0,0,1744374684,1744374684,1);
/*!40000 ALTER TABLE `comment_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `parent_id` bigint NOT NULL DEFAULT '0' COMMENT '父id',
  `type` bigint NOT NULL DEFAULT '1' COMMENT '数据类型',
  `content` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '评论内容',
  `resource_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '数据标题',
  `resource_id` bigint NOT NULL COMMENT '数据id',
  `form_member_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '评论会员id',
  `to_member_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '被评论会员id',
  `agree` bigint NOT NULL COMMENT '点赞数',
  `state` bigint NOT NULL COMMENT '状态 1待审核 2通过 3未通过',
  `note` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '不通过原因',
  `ip` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '评论者ip',
  `to_id` bigint NOT NULL DEFAULT '0' COMMENT '被评论Id',
  `to_content` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '被评论内容(冗余)',
  `notify_state` bigint NOT NULL DEFAULT '1' COMMENT '1已查看 2未查看',
  `create_at` bigint DEFAULT NULL,
  `update_at` bigint DEFAULT NULL,
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consult`
--

DROP TABLE IF EXISTS `consult`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consult` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `master_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '客户id',
  `slave_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '当前客服id',
  `completed` int NOT NULL DEFAULT '0' COMMENT '咨询是否结束{0:咨询中,1:已结束}',
  `master_ip` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '客户ip',
  `master_ip_region` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '客户ip归属地',
  `master_os` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '客户操作系统',
  `status` int NOT NULL DEFAULT '0' COMMENT '当前咨询状态{0:等待客服接入,1:聊天中,2:客户已离开,3:客服已离开,4:客服转接中,5:咨询结束}',
  `status_desc` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '当前咨询状态描述',
  `master_online` int NOT NULL DEFAULT '0' COMMENT '客户是否在线{0:不在线,1:在线}',
  `slave_access_type` int NOT NULL DEFAULT '0' COMMENT '客服接入类型{0:未接入,1:聊天接入,2:留言接入}',
  `transfer_slave_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '期待接入客服id|被转接的客服id',
  `scope` bigint NOT NULL DEFAULT '0' COMMENT '咨询记录范围值',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_consult_scope` (`scope`),
  KEY `idx_consult_create_at` (`create_at`),
  KEY `idx_consult_completed` (`completed`),
  KEY `idx_consult_master_online` (`master_online`),
  KEY `idx_consult_slave_access_type` (`slave_access_type`),
  KEY `idx_consult_transfer_slave_id` (`transfer_slave_id`),
  KEY `idx_consult_master_id` (`master_id`),
  KEY `idx_consult_slave_id` (`slave_id`),
  KEY `idx_consult_status` (`status`),
  KEY `idx_consult_update_at` (`update_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consult`
--

LOCK TABLES `consult` WRITE;
/*!40000 ALTER TABLE `consult` DISABLE KEYS */;
/*!40000 ALTER TABLE `consult` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consult_content`
--

DROP TABLE IF EXISTS `consult_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consult_content` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `consult_id` bigint NOT NULL DEFAULT '0' COMMENT '咨询id',
  `category` int NOT NULL DEFAULT '0' COMMENT '记录分类{0:未知消息,1:文本消息,2:图片消息,3:文件消息,4:音频消息,5:视频消息,6:订单消息,7:系统提示消息}',
  `sender_role` int NOT NULL DEFAULT '0' COMMENT '消息发送者角色{-1:系统,0:未知角色,1:客户,2:客服}',
  `sender_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '发送者id',
  `receiver_role` int NOT NULL DEFAULT '0' COMMENT '消息接收者角色{0:未知角色,1:客户,2:客服}',
  `receiver_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '接收者id',
  `whether_read` int NOT NULL DEFAULT '0' COMMENT '是否已读{0:否,1:是}',
  `send_at` bigint NOT NULL DEFAULT '0' COMMENT '发送消息时的毫秒时间戳',
  `leave_msg` int NOT NULL DEFAULT '0' COMMENT '是否是留言{0:否,1:是}',
  `system_msg` int NOT NULL DEFAULT '0' COMMENT '是否是系统消息{0:否,1:是}',
  `content` text COLLATE utf8mb4_unicode_ci COMMENT '记录内容',
  `mid` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '客户端消息id',
  `scope` bigint NOT NULL DEFAULT '0' COMMENT '咨询记录范围值',
  `site_id` bigint NOT NULL DEFAULT '0' COMMENT '客户对应的站点id',
  PRIMARY KEY (`id`),
  KEY `idx_consult_content_sender_id` (`sender_id`),
  KEY `idx_consult_content_receiver_role` (`receiver_role`),
  KEY `idx_consult_content_receiver_id` (`receiver_id`),
  KEY `idx_consult_content_whether_read` (`whether_read`),
  KEY `idx_consult_content_consult_id` (`consult_id`),
  KEY `idx_consult_content_send_at` (`send_at`),
  KEY `idx_consult_content_leave_msg` (`leave_msg`),
  KEY `idx_consult_content_scope` (`scope`),
  KEY `idx_consult_content_sender_role` (`sender_role`),
  KEY `idx_consult_content_site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consult_content`
--

LOCK TABLES `consult_content` WRITE;
/*!40000 ALTER TABLE `consult_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `consult_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_label`
--

DROP TABLE IF EXISTS `customer_label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_label` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` text COLLATE utf8mb4_unicode_ci COMMENT '标签',
  `status` bigint NOT NULL DEFAULT '1',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `user_count` bigint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_label`
--

LOCK TABLES `customer_label` WRITE;
/*!40000 ALTER TABLE `customer_label` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_user_label`
--

DROP TABLE IF EXISTS `customer_user_label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_user_label` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL COMMENT '客服id',
  `label_id` bigint DEFAULT NULL COMMENT '标签id',
  `create_at` bigint DEFAULT NULL,
  `update_at` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_customer_user_label_user_id` (`user_id`),
  KEY `idx_customer_user_label_label_id` (`label_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_user_label`
--

LOCK TABLES `customer_user_label` WRITE;
/*!40000 ALTER TABLE `customer_user_label` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_user_label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_user_login_log`
--

DROP TABLE IF EXISTS `customer_user_login_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_user_login_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL COMMENT '用户id',
  `user_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户名',
  `user_role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户角色',
  `login_ip` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '最后登录ip',
  `login_at` bigint NOT NULL COMMENT '最后登录时间',
  `login_location` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'ip地址信息',
  `info` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '登录信息',
  `user_agent` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'user-Agent',
  `device` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '设备',
  `os_version` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '系统版本',
  `browse` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '浏览器',
  `browse_version` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '浏览器版本',
  `resolution` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '分辨率',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_username` (`user_name`),
  KEY `idx_userrole` (`user_role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_user_login_log`
--

LOCK TABLES `customer_user_login_log` WRITE;
/*!40000 ALTER TABLE `customer_user_login_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_user_login_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_users`
--

DROP TABLE IF EXISTS `customer_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nick_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `head_img` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '头像',
  `sex` smallint NOT NULL DEFAULT '1' COMMENT '性别 1:男 2:女',
  `uuid` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `role` bigint NOT NULL DEFAULT '0',
  `status` bigint NOT NULL DEFAULT '1',
  `last_login_ip` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `last_login_at` bigint NOT NULL,
  `location_info` text COLLATE utf8mb4_unicode_ci,
  `permissions` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `site_ids` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '客服支持的站点 空:全部站点; 逗号分隔具体站点id(site_config.id)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_username` (`user_name`),
  KEY `uuid` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_users`
--

LOCK TABLES `customer_users` WRITE;
/*!40000 ALTER TABLE `customer_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `database_manage`
--

DROP TABLE IF EXISTS `database_manage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `database_manage` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `database_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `capacity` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci,
  `host` bigint DEFAULT NULL,
  `ips` text COLLATE utf8mb4_unicode_ci,
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `database_manage`
--

LOCK TABLES `database_manage` WRITE;
/*!40000 ALTER TABLE `database_manage` DISABLE KEYS */;
/*!40000 ALTER TABLE `database_manage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dns_setting`
--

DROP TABLE IF EXISTS `dns_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dns_setting` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `secret_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'dns secretId',
  `secret_key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '密钥',
  `state` bigint DEFAULT NULL COMMENT '状态 1启用 2禁用',
  `service_provider` bigint DEFAULT NULL COMMENT 'DNS服务商 1腾讯云 2阿里云 3第三方',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dns_setting`
--

LOCK TABLES `dns_setting` WRITE;
/*!40000 ALTER TABLE `dns_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `dns_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `domains`
--

DROP TABLE IF EXISTS `domains`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `domains` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `pid` bigint NOT NULL DEFAULT '0' COMMENT 'pid为0标识主域名，不为0标识主机头域名id @标识根域名',
  `domain_name` varchar(140) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '域名',
  `remark` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `host_head` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '主机头',
  `is_tls` bigint NOT NULL DEFAULT '1' COMMENT '是否强制TLS:1是 2否',
  `cert_status` bigint NOT NULL DEFAULT '0' COMMENT '证书状态:1未添加(手动) 2未申请(自动) 3申请中 4正常 5申请失败 6即将过期 7已过期 8已吊销',
  `message` text COLLATE utf8mb4_unicode_ci COMMENT '申请信息',
  `cer` text COLLATE utf8mb4_unicode_ci COMMENT '证书内容',
  `cer_key` text COLLATE utf8mb4_unicode_ci COMMENT '证书Key',
  `auto_apply` tinyint(1) DEFAULT NULL COMMENT '自动申请',
  `auto_renew` tinyint(1) DEFAULT NULL COMMENT '自动续签',
  `expired_time` bigint DEFAULT NULL COMMENT '过期时间',
  `expire_tip_time` bigint DEFAULT NULL COMMENT '过期提醒时间',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `resolver_type` bigint DEFAULT NULL COMMENT '解析方式 1http 2DNS',
  `dns_setting_id` bigint DEFAULT NULL COMMENT 'DNS配置id,解析方式位DNS时，必填',
  `show_date` bigint DEFAULT NULL COMMENT '前台作为主域名使用时间，以天为单位',
  `tls_type` bigint DEFAULT NULL COMMENT '1仅http 2仅https 3https+http 4强制https',
  `channel_id` bigint DEFAULT NULL COMMENT '渠道id',
  `channel_bind_at` bigint NOT NULL DEFAULT '0' COMMENT '渠道绑定时间',
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_domain_host` (`pid`,`domain_name`,`host_head`),
  KEY `idx_domains_site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `domains`
--

LOCK TABLES `domains` WRITE;
/*!40000 ALTER TABLE `domains` DISABLE KEYS */;
/*!40000 ALTER TABLE `domains` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expression`
--

DROP TABLE IF EXISTS `expression`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expression` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL COMMENT '用户id',
  `sort` bigint DEFAULT '0',
  `content` text COLLATE utf8mb4_unicode_ci COMMENT '内容',
  `status` bigint NOT NULL DEFAULT '1',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expression`
--

LOCK TABLES `expression` WRITE;
/*!40000 ALTER TABLE `expression` DISABLE KEYS */;
/*!40000 ALTER TABLE `expression` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favorite`
--

DROP TABLE IF EXISTS `favorite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `favorite` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `member_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '会员uuid',
  `type` bigint NOT NULL DEFAULT '1' COMMENT '数据类型,1-视频，3-资讯',
  `site_id` bigint NOT NULL DEFAULT '0' COMMENT '站点id',
  `resource_id` bigint NOT NULL COMMENT '数据id',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_favorite_member_id` (`member_id`),
  KEY `idx_favorite_site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorite`
--

LOCK TABLES `favorite` WRITE;
/*!40000 ALTER TABLE `favorite` DISABLE KEYS */;
/*!40000 ALTER TABLE `favorite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedbacks`
--

DROP TABLE IF EXISTS `feedbacks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feedbacks` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `member_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '会员uuid',
  `resources_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '订单Id|视频Id',
  `feedback_content` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '反馈内容',
  `reply_content` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '回复内容',
  `feedback_type` bigint NOT NULL COMMENT '反馈类型 1视频 2订单 3佣金 4体现',
  `reply_time` bigint NOT NULL COMMENT '回复时间',
  `reply_state` bigint NOT NULL COMMENT '回复状态 1已回复 2未回复',
  `state` bigint NOT NULL COMMENT '查看状态 1已查看 2未查看',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  PRIMARY KEY (`id`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedbacks`
--

LOCK TABLES `feedbacks` WRITE;
/*!40000 ALTER TABLE `feedbacks` DISABLE KEYS */;
/*!40000 ALTER TABLE `feedbacks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filter`
--

DROP TABLE IF EXISTS `filter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `filter` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `parent_id` bigint DEFAULT NULL COMMENT '父级id',
  `name` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '类型-年份，语言，地区',
  `config` text COLLATE utf8mb4_unicode_ci,
  `sort` bigint DEFAULT NULL,
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  PRIMARY KEY (`id`),
  KEY `idx_filter_site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filter`
--

LOCK TABLES `filter` WRITE;
/*!40000 ALTER TABLE `filter` DISABLE KEYS */;
/*!40000 ALTER TABLE `filter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ftp_users`
--

DROP TABLE IF EXISTS `ftp_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ftp_users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `root_dir` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `note` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_username` (`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ftp_users`
--

LOCK TABLES `ftp_users` WRITE;
/*!40000 ALTER TABLE `ftp_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `ftp_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `golds`
--

DROP TABLE IF EXISTS `golds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `golds` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `member_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '会员uuid',
  `type` smallint NOT NULL DEFAULT '1' COMMENT '类型 1:充值 2:赠送 3:消费',
  `remark` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '说明',
  `number` bigint NOT NULL DEFAULT '0' COMMENT '数量',
  `remaining_number` bigint NOT NULL DEFAULT '0' COMMENT '剩余数量',
  `resource_id` bigint NOT NULL DEFAULT '0' COMMENT '资源id',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  PRIMARY KEY (`id`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `golds`
--

LOCK TABLES `golds` WRITE;
/*!40000 ALTER TABLE `golds` DISABLE KEYS */;
/*!40000 ALTER TABLE `golds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ios_versions`
--

DROP TABLE IF EXISTS `ios_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ios_versions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `version_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '版本号',
  `icon` text COLLATE utf8mb4_unicode_ci COMMENT '版本图表base64',
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '应用名称',
  `appid` int unsigned DEFAULT NULL COMMENT 'APPID',
  `status` bigint DEFAULT NULL COMMENT '状态0-未发布，1-已发布',
  `file_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '文件路劲',
  `permanent_domain` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '永久通讯域名',
  `visit_domain` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '访问站点域名',
  `channel_id` bigint NOT NULL DEFAULT '0' COMMENT '渠道id',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ios_versions`
--

LOCK TABLES `ios_versions` WRITE;
/*!40000 ALTER TABLE `ios_versions` DISABLE KEYS */;
/*!40000 ALTER TABLE `ios_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `label`
--

DROP TABLE IF EXISTS `label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `label` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '标签名称',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  PRIMARY KEY (`id`),
  KEY `idx_label_site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `label`
--

LOCK TABLES `label` WRITE;
/*!40000 ALTER TABLE `label` DISABLE KEYS */;
/*!40000 ALTER TABLE `label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language`
--

DROP TABLE IF EXISTS `language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `language` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '语言名称',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  PRIMARY KEY (`id`),
  KEY `idx_language_site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language`
--

LOCK TABLES `language` WRITE;
/*!40000 ALTER TABLE `language` DISABLE KEYS */;
/*!40000 ALTER TABLE `language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lets_encrypt`
--

DROP TABLE IF EXISTS `lets_encrypt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lets_encrypt` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'email',
  `private_key` text COLLATE utf8mb4_unicode_ci COMMENT '账号key',
  `registration` text COLLATE utf8mb4_unicode_ci COMMENT 'lets Encrypt注册信息',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lets_encrypt`
--

LOCK TABLES `lets_encrypt` WRITE;
/*!40000 ALTER TABLE `lets_encrypt` DISABLE KEYS */;
/*!40000 ALTER TABLE `lets_encrypt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `links`
--

DROP TABLE IF EXISTS `links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `links` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `group_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '分组名',
  `link` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '链接',
  `sort` bigint DEFAULT NULL COMMENT '排序',
  `state` bigint DEFAULT NULL COMMENT '状态 1启用 2禁用',
  `bold` tinyint(1) DEFAULT NULL COMMENT '是否是粗体',
  `color` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '颜色',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `is_all_site` int NOT NULL DEFAULT '2' COMMENT '是否是全站应用,1-是，2-否',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `links`
--

LOCK TABLES `links` WRITE;
/*!40000 ALTER TABLE `links` DISABLE KEYS */;
/*!40000 ALTER TABLE `links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_log`
--

DROP TABLE IF EXISTS `login_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL COMMENT '用户id',
  `user_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户名',
  `user_role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户角色',
  `login_ip` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '最后登录ip',
  `login_at` bigint NOT NULL COMMENT '最后登录时间',
  `login_location` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'ip地址信息',
  `info` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '登录信息',
  `user_agent` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'user-Agent',
  `device` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '设备',
  `os_version` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '系统版本',
  `browse` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '浏览器',
  `browse_version` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '浏览器版本',
  `resolution` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '分辨率',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_username` (`user_name`),
  KEY `idx_userrole` (`user_role`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_log`
--

LOCK TABLES `login_log` WRITE;
/*!40000 ALTER TABLE `login_log` DISABLE KEYS */;
INSERT INTO `login_log` VALUES (1,1,'admin','1','46.3.240.74',1744374636,'台湾省台北市 CZ88.NET','台湾省台北市 CZ88.NET','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','PC','10.0','Chrome','135.0.0.0','2560*1440',1744374636,1744374636);
/*!40000 ALTER TABLE `login_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_group`
--

DROP TABLE IF EXISTS `member_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_group` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '会员分组名称',
  `name_key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '会员分组名称标识',
  `site_id` bigint NOT NULL DEFAULT '0' COMMENT '站点id',
  `can_delete` bigint DEFAULT '1' COMMENT '是否可以删除',
  `permission` text COLLATE utf8mb4_unicode_ci,
  `description` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `idx_member_group_site_id` (`site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_group`
--

LOCK TABLES `member_group` WRITE;
/*!40000 ALTER TABLE `member_group` DISABLE KEYS */;
INSERT INTO `member_group` VALUES (1,'游客','tourists',1,1,'[{\"categoryId\":1,\"categoryName\":\"电影\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":2,\"categoryName\":\"电视剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":3,\"categoryName\":\"综艺\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":4,\"categoryName\":\"动漫\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":5,\"categoryName\":\"演员\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":6,\"categoryName\":\"导演\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":7,\"categoryName\":\"作家\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":8,\"categoryName\":\"编剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":9,\"categoryName\":\"动作片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":10,\"categoryName\":\"喜剧片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":11,\"categoryName\":\"爱情片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":12,\"categoryName\":\"恐怖片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":13,\"categoryName\":\"剧情片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":14,\"categoryName\":\"科幻片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":15,\"categoryName\":\"惊悚片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":16,\"categoryName\":\"奇幻片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":17,\"categoryName\":\"动画片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":18,\"categoryName\":\"悬疑片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":19,\"categoryName\":\"冒险片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":20,\"categoryName\":\"纪录片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":21,\"categoryName\":\"战争片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":22,\"categoryName\":\"国产剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":23,\"categoryName\":\"香港剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":24,\"categoryName\":\"台湾剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":25,\"categoryName\":\"欧美剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":26,\"categoryName\":\"日本剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":27,\"categoryName\":\"韩国剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":28,\"categoryName\":\"泰国剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":29,\"categoryName\":\"海外剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":30,\"categoryName\":\"大陆综艺\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":31,\"categoryName\":\"港台综艺\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":32,\"categoryName\":\"日韩综艺\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":33,\"categoryName\":\"欧美综艺\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":34,\"categoryName\":\"海外综艺\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":35,\"categoryName\":\"国产动漫\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":36,\"categoryName\":\"日本动漫\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":37,\"categoryName\":\"欧美动漫\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":38,\"categoryName\":\"海外动漫\",\"permission\":7,\"permissionItem\":[1,2,4]}]',''),(2,'普通会员','general',1,1,'[{\"categoryId\":1,\"categoryName\":\"电影\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":2,\"categoryName\":\"电视剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":3,\"categoryName\":\"综艺\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":4,\"categoryName\":\"动漫\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":5,\"categoryName\":\"演员\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":6,\"categoryName\":\"导演\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":7,\"categoryName\":\"作家\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":8,\"categoryName\":\"编剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":9,\"categoryName\":\"动作片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":10,\"categoryName\":\"喜剧片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":11,\"categoryName\":\"爱情片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":12,\"categoryName\":\"恐怖片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":13,\"categoryName\":\"剧情片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":14,\"categoryName\":\"科幻片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":15,\"categoryName\":\"惊悚片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":16,\"categoryName\":\"奇幻片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":17,\"categoryName\":\"动画片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":18,\"categoryName\":\"悬疑片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":19,\"categoryName\":\"冒险片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":20,\"categoryName\":\"纪录片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":21,\"categoryName\":\"战争片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":22,\"categoryName\":\"国产剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":23,\"categoryName\":\"香港剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":24,\"categoryName\":\"台湾剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":25,\"categoryName\":\"欧美剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":26,\"categoryName\":\"日本剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":27,\"categoryName\":\"韩国剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":28,\"categoryName\":\"泰国剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":29,\"categoryName\":\"海外剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":30,\"categoryName\":\"大陆综艺\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":31,\"categoryName\":\"港台综艺\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":32,\"categoryName\":\"日韩综艺\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":33,\"categoryName\":\"欧美综艺\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":34,\"categoryName\":\"海外综艺\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":35,\"categoryName\":\"国产动漫\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":36,\"categoryName\":\"日本动漫\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":37,\"categoryName\":\"欧美动漫\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":38,\"categoryName\":\"海外动漫\",\"permission\":7,\"permissionItem\":[1,2,4]}]',''),(3,'vip','vip',1,1,'[{\"categoryId\":1,\"categoryName\":\"电影\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":2,\"categoryName\":\"电视剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":3,\"categoryName\":\"综艺\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":4,\"categoryName\":\"动漫\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":5,\"categoryName\":\"演员\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":6,\"categoryName\":\"导演\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":7,\"categoryName\":\"作家\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":8,\"categoryName\":\"编剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":9,\"categoryName\":\"动作片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":10,\"categoryName\":\"喜剧片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":11,\"categoryName\":\"爱情片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":12,\"categoryName\":\"恐怖片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":13,\"categoryName\":\"剧情片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":14,\"categoryName\":\"科幻片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":15,\"categoryName\":\"惊悚片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":16,\"categoryName\":\"奇幻片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":17,\"categoryName\":\"动画片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":18,\"categoryName\":\"悬疑片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":19,\"categoryName\":\"冒险片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":20,\"categoryName\":\"纪录片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":21,\"categoryName\":\"战争片\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":22,\"categoryName\":\"国产剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":23,\"categoryName\":\"香港剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":24,\"categoryName\":\"台湾剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":25,\"categoryName\":\"欧美剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":26,\"categoryName\":\"日本剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":27,\"categoryName\":\"韩国剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":28,\"categoryName\":\"泰国剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":29,\"categoryName\":\"海外剧\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":30,\"categoryName\":\"大陆综艺\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":31,\"categoryName\":\"港台综艺\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":32,\"categoryName\":\"日韩综艺\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":33,\"categoryName\":\"欧美综艺\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":34,\"categoryName\":\"海外综艺\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":35,\"categoryName\":\"国产动漫\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":36,\"categoryName\":\"日本动漫\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":37,\"categoryName\":\"欧美动漫\",\"permission\":7,\"permissionItem\":[1,2,4]},{\"categoryId\":38,\"categoryName\":\"海外动漫\",\"permission\":7,\"permissionItem\":[1,2,4]}]','');
/*!40000 ALTER TABLE `member_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_login_log`
--

DROP TABLE IF EXISTS `member_login_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_login_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `member_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '会员uuid',
  `login_ip` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '最后登录ip',
  `login_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '登录类型',
  `login_at` bigint NOT NULL COMMENT '最后登录时间',
  `login_location` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'ip地址信息',
  `user_agent` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'user-Agent',
  `resolving` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '分辨率',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `is_visitor` bigint DEFAULT '2' COMMENT '是否是游客1-是，2-会员',
  PRIMARY KEY (`id`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_login_log`
--

LOCK TABLES `member_login_log` WRITE;
/*!40000 ALTER TABLE `member_login_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_login_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_register_log`
--

DROP TABLE IF EXISTS `member_register_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_register_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `member_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '会员uuid',
  `register_ip` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '最后登录ip',
  `register_at` bigint NOT NULL COMMENT '注册时间',
  `location` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'ip地址信息',
  `user_agent` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'user-Agent',
  `resolving` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '分辨率',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_register_log`
--

LOCK TABLES `member_register_log` WRITE;
/*!40000 ALTER TABLE `member_register_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_register_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_sign`
--

DROP TABLE IF EXISTS `member_sign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_sign` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `member_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '会员uuid',
  `task_id` bigint NOT NULL COMMENT '签到任务id',
  `number` bigint NOT NULL COMMENT '签到天数',
  `state` bigint NOT NULL DEFAULT '2' COMMENT '状态 1已完成 2未完成',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_member_task` (`member_id`,`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_sign`
--

LOCK TABLES `member_sign` WRITE;
/*!40000 ALTER TABLE `member_sign` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_sign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_sign_log`
--

DROP TABLE IF EXISTS `member_sign_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_sign_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `member_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '会员uuid',
  `sign_date` bigint NOT NULL COMMENT '签到日期',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_member_id_data` (`member_id`,`sign_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_sign_log`
--

LOCK TABLES `member_sign_log` WRITE;
/*!40000 ALTER TABLE `member_sign_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_sign_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_task_progress`
--

DROP TABLE IF EXISTS `member_task_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_task_progress` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `member_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '会员uuid',
  `task_id` bigint NOT NULL DEFAULT '0' COMMENT '任务id',
  `progress` bigint NOT NULL DEFAULT '0' COMMENT '单次任务进度',
  `task_count` bigint NOT NULL DEFAULT '0' COMMENT '总任务进度(任务完成次数)',
  `state` smallint NOT NULL DEFAULT '2' COMMENT '1已完成 2未完成',
  `rest_time` bigint NOT NULL DEFAULT '0' COMMENT '重置时间(上次)',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_task_progress`
--

LOCK TABLES `member_task_progress` WRITE;
/*!40000 ALTER TABLE `member_task_progress` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_task_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_tasks`
--

DROP TABLE IF EXISTS `member_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_tasks` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '标题',
  `info` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '任务介绍',
  `task_type` smallint NOT NULL DEFAULT '0' COMMENT '任务类型 1观看视频',
  `sort` bigint NOT NULL DEFAULT '0' COMMENT '排序',
  `gold_coin` bigint NOT NULL DEFAULT '0' COMMENT '奖励金币数量',
  `parameter` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '任务参数',
  `ceiling` smallint NOT NULL DEFAULT '0' COMMENT '每天奖励次数上限',
  `state` smallint NOT NULL DEFAULT '0' COMMENT '1开启 2关闭',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `site_id` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_tasks`
--

LOCK TABLES `member_tasks` WRITE;
/*!40000 ALTER TABLE `member_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_vip_log`
--

DROP TABLE IF EXISTS `member_vip_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_vip_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `member_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '会员uuid',
  `number` bigint NOT NULL COMMENT '天数(存储对应的秒数)',
  `expire_time` bigint NOT NULL DEFAULT '0' COMMENT '过期时间',
  `info` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '信息',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_vip_log`
--

LOCK TABLES `member_vip_log` WRITE;
/*!40000 ALTER TABLE `member_vip_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_vip_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户名',
  `nickname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '昵称',
  `group_name` smallint NOT NULL DEFAULT '1' COMMENT '分组 1:普通 2:VIP',
  `gold_tag` smallint NOT NULL DEFAULT '1' COMMENT '金币点播会员 1:是 2:不是 ',
  `head_img` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '头像',
  `sex` smallint NOT NULL DEFAULT '1' COMMENT '性别 1:男 2:女',
  `birthday` bigint NOT NULL DEFAULT '0' COMMENT '生日',
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '密码',
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '手机号',
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '邮箱',
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '地址',
  `desc` varchar(5000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '简介',
  `expire_time` bigint NOT NULL DEFAULT '0' COMMENT '到期时间',
  `edit_name` smallint NOT NULL DEFAULT '1' COMMENT '是否允许修改用户名 1允许 2不允许',
  `gold_coin` bigint NOT NULL DEFAULT '0' COMMENT '金币',
  `last_login_ip` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '最近登录ip',
  `last_login_at` bigint NOT NULL COMMENT '最近登录时间',
  `register_type` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'web' COMMENT '注册类型 H5,web,app',
  `fund_password` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '资金密码',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `is_tourists` smallint DEFAULT '2' COMMENT '是否为游客 1游客',
  `deleted_at` datetime DEFAULT NULL,
  `channel_id` bigint DEFAULT NULL COMMENT '渠道id',
  `domain_id` bigint DEFAULT NULL COMMENT '域名id',
  `register_domain` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '注册域名',
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  `member_group_id` int NOT NULL DEFAULT '0',
  `register_mode` int NOT NULL DEFAULT '3',
  `got_vip_days` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_name` (`name`),
  UNIQUE KEY `email` (`email`,`site_id`),
  UNIQUE KEY `idx_email` (`email`,`site_id`,`deleted_at`),
  UNIQUE KEY `idx_phone` (`phone`,`site_id`,`deleted_at`),
  UNIQUE KEY `name` (`name`,`site_id`,`deleted_at`),
  KEY `idx_members_site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members`
--

LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message_board`
--

DROP TABLE IF EXISTS `message_board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_board` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `member_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '会员uuid',
  `username` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户名称',
  `content` text COLLATE utf8mb4_unicode_ci COMMENT '反馈内容',
  `reply` text COLLATE utf8mb4_unicode_ci COMMENT '回复内容',
  `reply_time` bigint NOT NULL COMMENT '回复时间',
  `state` bigint NOT NULL COMMENT '状态 1已回复 2未回复',
  `ip` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '留言Ip',
  `create_at` bigint NOT NULL DEFAULT '0',
  `update_at` bigint NOT NULL DEFAULT '0',
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  PRIMARY KEY (`id`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_board`
--

LOCK TABLES `message_board` WRITE;
/*!40000 ALTER TABLE `message_board` DISABLE KEYS */;
/*!40000 ALTER TABLE `message_board` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrate`
--

DROP TABLE IF EXISTS `migrate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrate` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `hash` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `execute_statement` text COLLATE utf8mb4_unicode_ci,
  `message` text COLLATE utf8mb4_unicode_ci,
  `create_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_migrate_hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrate`
--

LOCK TABLES `migrate` WRITE;
/*!40000 ALTER TABLE `migrate` DISABLE KEYS */;
/*!40000 ALTER TABLE `migrate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notices`
--

DROP TABLE IF EXISTS `notices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notices` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `content` text COLLATE utf8mb4_unicode_ci COMMENT '内容',
  `notice_type` bigint NOT NULL COMMENT '公告类型 2普通 1弹窗',
  `state` bigint NOT NULL COMMENT '状态 1启用 2禁用',
  `sort` bigint NOT NULL COMMENT '排序',
  `start_time` bigint NOT NULL COMMENT '启用时间',
  `expiration_time` bigint NOT NULL COMMENT '过期时间',
  `link` text COLLATE utf8mb4_unicode_ci COMMENT '跳转链接',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `is_all_site` int NOT NULL DEFAULT '1' COMMENT '是否是全站应用,1-是，2-否',
  `popup_trigger` int NOT NULL DEFAULT '0' COMMENT '弹窗触发方式1-每次都弹，2-只弹一次',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notices`
--

LOCK TABLES `notices` WRITE;
/*!40000 ALTER TABLE `notices` DISABLE KEYS */;
/*!40000 ALTER TABLE `notices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `novel`
--

DROP TABLE IF EXISTS `novel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `novel` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '名称',
  `intro` text COMMENT '简介',
  `category_pid` bigint NOT NULL DEFAULT '0' COMMENT '分类1级id',
  `category_child_id` bigint NOT NULL DEFAULT '0' COMMENT '分类二级id',
  `is_end` int NOT NULL DEFAULT '2' COMMENT '是否完结 1完结 2未完结',
  `cover` text COMMENT '封面图片地址',
  `author` varchar(50) NOT NULL DEFAULT '' COMMENT '作者',
  `release_date` bigint NOT NULL DEFAULT '0' COMMENT '发布日期',
  `status` int NOT NULL DEFAULT '1' COMMENT '状态 1正常',
  `site_id` bigint NOT NULL DEFAULT '1' COMMENT '站点id',
  `words_number` int NOT NULL DEFAULT '0' COMMENT '字数',
  `create_at` bigint DEFAULT NULL,
  `update_at` bigint DEFAULT NULL,
  `label` varchar(256) NOT NULL DEFAULT '' COMMENT '标签',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='小说表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `novel`
--

LOCK TABLES `novel` WRITE;
/*!40000 ALTER TABLE `novel` DISABLE KEYS */;
/*!40000 ALTER TABLE `novel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `novel_celebrities`
--

DROP TABLE IF EXISTS `novel_celebrities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `novel_celebrities` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `celebrity_id` bigint NOT NULL DEFAULT '0' COMMENT '名人id',
  `novel_id` bigint NOT NULL DEFAULT '0' COMMENT '小说id',
  `site_id` bigint NOT NULL DEFAULT '1' COMMENT '站点id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='小说名人';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `novel_celebrities`
--

LOCK TABLES `novel_celebrities` WRITE;
/*!40000 ALTER TABLE `novel_celebrities` DISABLE KEYS */;
/*!40000 ALTER TABLE `novel_celebrities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `open_collect_auth`
--

DROP TABLE IF EXISTS `open_collect_auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `open_collect_auth` (
  `id` int NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL COMMENT '站点id',
  `auth_domain` text COMMENT '授权域名,逗号分隔ip或域名',
  `start_time` bigint DEFAULT '0' COMMENT '开始日期秒,日期0秒',
  `end_time` bigint DEFAULT '0' COMMENT '到期日期,日期59分59秒',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态，0-未启用，1-已启用',
  `remark` text COMMENT '备注',
  `create_at` bigint NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_at` bigint NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_collect_auth`
--

LOCK TABLES `open_collect_auth` WRITE;
/*!40000 ALTER TABLE `open_collect_auth` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_collect_auth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages`
--

DROP TABLE IF EXISTS `packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `packages` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '套餐名称',
  `type` bigint NOT NULL DEFAULT '0' COMMENT '套餐类型 1vip套餐 2金币套餐 3兑换套餐',
  `price` bigint NOT NULL DEFAULT '0' COMMENT '价格(单位分)|金币数量',
  `number` bigint NOT NULL DEFAULT '0' COMMENT '金币数量|天数',
  `sort` bigint NOT NULL DEFAULT '1' COMMENT '排序',
  `state` bigint NOT NULL COMMENT '状态 1启用 2禁用',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `member_group_id` int NOT NULL DEFAULT '0' COMMENT '会员分组id',
  `site_id` int NOT NULL DEFAULT '1',
  `group_id` int NOT NULL DEFAULT '1',
  `description` text COLLATE utf8mb4_unicode_ci,
  `discount_desc` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages`
--

LOCK TABLES `packages` WRITE;
/*!40000 ALTER TABLE `packages` DISABLE KEYS */;
/*!40000 ALTER TABLE `packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages_group`
--

DROP TABLE IF EXISTS `packages_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `packages_group` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sort` bigint NOT NULL DEFAULT '1' COMMENT '排序',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `member_group_id` bigint DEFAULT '0',
  `site_id` bigint NOT NULL DEFAULT '0' COMMENT '站点id',
  `description` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `idx_packages_group_site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages_group`
--

LOCK TABLES `packages_group` WRITE;
/*!40000 ALTER TABLE `packages_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `packages_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_argument`
--

DROP TABLE IF EXISTS `pay_argument`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pay_argument` (
  `id` varchar(36) NOT NULL COMMENT '主键-uuid',
  `title` varchar(150) NOT NULL DEFAULT '' COMMENT '配置标题',
  `calc_id` varchar(36) NOT NULL DEFAULT '' COMMENT '算法ID，空则不执行算法(签名表Id)',
  `pay_id` varchar(36) NOT NULL DEFAULT '' COMMENT '支付配置ID',
  `config` text COMMENT '配置项(JSON字符串)',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='支付参数表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_argument`
--

LOCK TABLES `pay_argument` WRITE;
/*!40000 ALTER TABLE `pay_argument` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_argument` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_config`
--

DROP TABLE IF EXISTS `pay_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pay_config` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `pay_method` smallint NOT NULL DEFAULT '0' COMMENT '支付方式 1支付宝 2微信 3其他支付',
  `status` smallint NOT NULL DEFAULT '1' COMMENT '状态 1开启 2关闭',
  `sort` bigint NOT NULL DEFAULT '1' COMMENT '排序值',
  `parameter` text COLLATE utf8mb4_unicode_ci COMMENT '参数',
  `day_max_money` bigint NOT NULL DEFAULT '0' COMMENT '单日最高收款金额 单位分',
  `once_max_money` bigint NOT NULL DEFAULT '0' COMMENT '单笔最高收款金额 单位分',
  `today_money` bigint NOT NULL DEFAULT '0' COMMENT '当日已用额度 单位分',
  `rest_time` bigint NOT NULL DEFAULT '0' COMMENT '当日额度重置时间',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_config`
--

LOCK TABLES `pay_config` WRITE;
/*!40000 ALTER TABLE `pay_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_disposition`
--

DROP TABLE IF EXISTS `pay_disposition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pay_disposition` (
  `id` varchar(36) NOT NULL COMMENT '主键-uuid',
  `ceiling_amount` bigint NOT NULL DEFAULT '0' COMMENT '上限金额',
  `minimum_amount` bigint NOT NULL DEFAULT '0' COMMENT '下限金额',
  `title` varchar(150) NOT NULL DEFAULT '' COMMENT '支付名称',
  `state` bigint NOT NULL DEFAULT '1' COMMENT '状态 1启用，否则不启用',
  `client_web` bigint NOT NULL DEFAULT '1' COMMENT '支持 1支持，否则不支持',
  `client_h5` bigint NOT NULL DEFAULT '2' COMMENT '支持 1支持，否则不支持',
  `client_app` bigint NOT NULL DEFAULT '2' COMMENT '支持 1支持，否则不支持',
  `make_order` varchar(36) NOT NULL DEFAULT '' COMMENT '统一下单(接口表id)',
  `query_order` varchar(36) NOT NULL DEFAULT '' COMMENT '查询订单(接口表id)',
  `config` text COMMENT '支付公共配置(JSON字符串)',
  `pay_type` varchar(50) NOT NULL DEFAULT 'custom' COMMENT '支付类型',
  `pay_config_id` bigint NOT NULL DEFAULT '0' COMMENT '关联pay_config表id',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `document_url` varchar(150) NOT NULL DEFAULT '' COMMENT '文档地址',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='支付配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_disposition`
--

LOCK TABLES `pay_disposition` WRITE;
/*!40000 ALTER TABLE `pay_disposition` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_disposition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_interface`
--

DROP TABLE IF EXISTS `pay_interface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pay_interface` (
  `id` varchar(36) NOT NULL COMMENT '主键-uuid',
  `addr` text COMMENT '接口地址',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '标题',
  `pay_id` varchar(36) NOT NULL DEFAULT '' COMMENT '支付配置表id',
  `method` varchar(10) NOT NULL DEFAULT '' COMMENT '请求方式',
  `content_type` varchar(100) NOT NULL DEFAULT '' COMMENT '请求类型',
  `accept` varchar(100) NOT NULL DEFAULT '' COMMENT '接收头类型',
  `header_id` varchar(36) NOT NULL DEFAULT '' COMMENT '发送头标识(配置表id)',
  `body_id` varchar(36) NOT NULL DEFAULT '' COMMENT '发送数据标识(配置表id)',
  `response` text COMMENT '响应数据(JSON字符串)',
  `bind_data` text COMMENT '绑定数据(JSON字符串)',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='支付接口表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_interface`
--

LOCK TABLES `pay_interface` WRITE;
/*!40000 ALTER TABLE `pay_interface` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_interface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_sign`
--

DROP TABLE IF EXISTS `pay_sign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pay_sign` (
  `id` varchar(36) NOT NULL COMMENT '主键-uuid',
  `title` varchar(150) NOT NULL DEFAULT '' COMMENT '算法名称',
  `pay_id` varchar(36) NOT NULL DEFAULT '' COMMENT '支付配置ID',
  `argument_id` varchar(36) NOT NULL DEFAULT '' COMMENT '参数ID',
  `type` bigint NOT NULL DEFAULT '0' COMMENT '验证类型，http=接口验证 custom=算法验证',
  `addr_id` varchar(36) NOT NULL DEFAULT '' COMMENT '接口地址ID(接口表Id)',
  `process` text COMMENT '操作流程(JSON字符串)',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='支付签名表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_sign`
--

LOCK TABLES `pay_sign` WRITE;
/*!40000 ALTER TABLE `pay_sign` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_sign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_transaction`
--

DROP TABLE IF EXISTS `pay_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pay_transaction` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app_id` varchar(40) NOT NULL DEFAULT '' COMMENT '应用id',
  `pay_method` smallint NOT NULL DEFAULT '0' COMMENT '支付方式 1支付宝 2微信',
  `pay_config_id` bigint NOT NULL DEFAULT '0' COMMENT '支付配置Id',
  `order_id` varchar(70) NOT NULL DEFAULT '' COMMENT '订单id',
  `trade_no` varchar(70) NOT NULL DEFAULT '' COMMENT '第三方的流水号(订单号)',
  `member_id` varchar(100) NOT NULL COMMENT '会员uuid',
  `recharge_type` smallint NOT NULL DEFAULT '0' COMMENT ' 1.套餐充值 2.自定义',
  `total_fee` bigint NOT NULL DEFAULT '0' COMMENT '支付金额-单位分',
  `expire_time` bigint NOT NULL DEFAULT '0' COMMENT '订单过期时间',
  `order_status` smallint NOT NULL DEFAULT '1' COMMENT '订单状态 1待付款 2完成支付 3失败',
  `package_id` bigint NOT NULL DEFAULT '0' COMMENT '套餐ID',
  `note` varchar(256) NOT NULL DEFAULT '' COMMENT '备注信息',
  `pay_ip` varchar(256) NOT NULL DEFAULT '' COMMENT '发起支付的ip',
  `recharge_kind` smallint NOT NULL DEFAULT '0' COMMENT ' 1充值vip 2充值金币',
  `parameter` text COMMENT '记录套餐数值和兑换比例',
  `paid_time` bigint NOT NULL DEFAULT '0' COMMENT '订单付款时间',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `brokerage` bigint NOT NULL DEFAULT '0' COMMENT '是否开启代理分佣{0:未开启,1:已开启}',
  `brokerage_result` bigint NOT NULL DEFAULT '0' COMMENT '代理分佣结果{0:未分佣,1:已分佣}',
  `brokerage_tips` varchar(256) NOT NULL DEFAULT '' COMMENT '分佣提示',
  `member_recharge_total` bigint NOT NULL DEFAULT '0' COMMENT '是否累计用户充值{0:未累计,1:已累计}',
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  `pay_disposition_id` varchar(36) NOT NULL DEFAULT '' COMMENT '关联pay_disposition表id',
  PRIMARY KEY (`id`),
  KEY `idx_member_id` (`member_id`),
  KEY `idx_pt_site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_transaction`
--

LOCK TABLES `pay_transaction` WRITE;
/*!40000 ALTER TABLE `pay_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `play_line`
--

DROP TABLE IF EXISTS `play_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `play_line` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `video_line_id` bigint DEFAULT NULL COMMENT '资源id',
  `video_id` bigint DEFAULT NULL,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `sort` bigint NOT NULL COMMENT '序号',
  `file` text COLLATE utf8mb4_unicode_ci COMMENT '文件地址',
  `charging_mode` bigint NOT NULL COMMENT '收费模式 1免费 2vip免费 3金币点播',
  `currency` bigint NOT NULL COMMENT '金币数量',
  `sub_title` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '副标题',
  `status` bigint NOT NULL DEFAULT '1',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  `tag` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '标识',
  `live_source` int NOT NULL DEFAULT '0' COMMENT '是否是直播源1-是 0-否',
  PRIMARY KEY (`id`),
  KEY `idx_play_line_video_id` (`video_id`),
  KEY `idx_play_line_line_id` (`video_line_id`),
  KEY `idx_play_line_site_id` (`site_id`),
  KEY `idx_play_line_tag` (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `play_line`
--

LOCK TABLES `play_line` WRITE;
/*!40000 ALTER TABLE `play_line` DISABLE KEYS */;
/*!40000 ALTER TABLE `play_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player`
--

DROP TABLE IF EXISTS `player`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `tag` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '标识',
  `sort` bigint NOT NULL COMMENT '序号',
  `type` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '类型 web:页面类型 custom:自定义',
  `status` bigint NOT NULL DEFAULT '1' COMMENT '状态 1启用 2禁用',
  `introduce` text COLLATE utf8mb4_unicode_ci COMMENT '简介',
  `code` text COLLATE utf8mb4_unicode_ci COMMENT '自定义代码',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `parse_mod` int NOT NULL DEFAULT '0' COMMENT '1-解析模式，2-高级模式，3-json解析模式',
  `parse_address` text COLLATE utf8mb4_unicode_ci COMMENT '解析地址，视频播放地址',
  `parse_column` text COLLATE utf8mb4_unicode_ci COMMENT 'Json解析字段',
  `json_server` text COLLATE utf8mb4_unicode_ci COMMENT 'Json解析服务',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player`
--

LOCK TABLES `player` WRITE;
/*!40000 ALTER TABLE `player` DISABLE KEYS */;
/*!40000 ALTER TABLE `player` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_collection`
--

DROP TABLE IF EXISTS `player_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_collection` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `player_id` bigint NOT NULL DEFAULT '0' COMMENT '广告id',
  `collection_id` bigint NOT NULL DEFAULT '0' COMMENT '资源Id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_collection`
--

LOCK TABLES `player_collection` WRITE;
/*!40000 ALTER TABLE `player_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_tags`
--

DROP TABLE IF EXISTS `player_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_tags` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `player_id` bigint NOT NULL DEFAULT '0' COMMENT '广告id',
  `tag` varchar(256) NOT NULL DEFAULT '' COMMENT '标识',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_tags`
--

LOCK TABLES `player_tags` WRITE;
/*!40000 ALTER TABLE `player_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publishes`
--

DROP TABLE IF EXISTS `publishes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `publishes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `publish_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publishes`
--

LOCK TABLES `publishes` WRITE;
/*!40000 ALTER TABLE `publishes` DISABLE KEYS */;
/*!40000 ALTER TABLE `publishes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_answer`
--

DROP TABLE IF EXISTS `question_answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question_answer` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT '0' COMMENT '用户id',
  `sort` bigint DEFAULT '0',
  `title` text COLLATE utf8mb4_unicode_ci COMMENT '标题',
  `answer` text COLLATE utf8mb4_unicode_ci COMMENT '内容',
  `qa_type` bigint DEFAULT NULL,
  `status` bigint NOT NULL DEFAULT '1',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_answer`
--

LOCK TABLES `question_answer` WRITE;
/*!40000 ALTER TABLE `question_answer` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_answer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `region`
--

DROP TABLE IF EXISTS `region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `region` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '地区名称',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  PRIMARY KEY (`id`),
  KEY `idx_region_site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `region`
--

LOCK TABLES `region` WRITE;
/*!40000 ALTER TABLE `region` DISABLE KEYS */;
/*!40000 ALTER TABLE `region` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rewards`
--

DROP TABLE IF EXISTS `rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rewards` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '任务标题',
  `desc` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '任务介绍',
  `gold_num` bigint NOT NULL DEFAULT '0' COMMENT '奖励金币数量',
  `reward_num` bigint NOT NULL DEFAULT '0' COMMENT '每天奖励次数',
  `view_duration` bigint NOT NULL DEFAULT '0' COMMENT '观看时长(秒)',
  `type` bigint NOT NULL DEFAULT '0' COMMENT '任务类型：1-观看，2-其他',
  `sort` bigint NOT NULL DEFAULT '0' COMMENT '任务类型：排序',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rewards`
--

LOCK TABLES `rewards` WRITE;
/*!40000 ALTER TABLE `rewards` DISABLE KEYS */;
/*!40000 ALTER TABLE `rewards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rewrite_rule`
--

DROP TABLE IF EXISTS `rewrite_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rewrite_rule` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sort` bigint NOT NULL DEFAULT '0' COMMENT '排序',
  `static_rule` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '静态替换规则',
  `real_route` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '真实地址web',
  `real_route_h5` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '真实地址h5',
  `status` bigint NOT NULL DEFAULT '2' COMMENT '状态 1开启 2关闭',
  `site_id` bigint NOT NULL DEFAULT '0' COMMENT '站点id',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
  `open_window` int NOT NULL DEFAULT '2' COMMENT '是否新开窗口 1:是 2:否',
  `ignore_overflow` int NOT NULL DEFAULT '2' COMMENT '是否忽略溢出参数 1:忽略 2:保留',
  PRIMARY KEY (`id`),
  KEY `idx_rewrite_rule_site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rewrite_rule`
--

LOCK TABLES `rewrite_rule` WRITE;
/*!40000 ALTER TABLE `rewrite_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `rewrite_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_chains`
--

DROP TABLE IF EXISTS `security_chains`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `security_chains` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL DEFAULT '0' COMMENT '站点id',
  `domain_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '允许域名',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_security_chains_domain_name` (`domain_name`),
  KEY `idx_security_chains_site_id` (`site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_chains`
--

LOCK TABLES `security_chains` WRITE;
/*!40000 ALTER TABLE `security_chains` DISABLE KEYS */;
INSERT INTO `security_chains` VALUES (1,1,'test.123.xyz',1744374684,1744374684);
/*!40000 ALTER TABLE `security_chains` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seo_rules`
--

DROP TABLE IF EXISTS `seo_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seo_rules` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `rule` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '规则',
  `param` text COLLATE utf8mb4_unicode_ci,
  `priority` float NOT NULL DEFAULT '0' COMMENT '权重 0.0--1.0之间',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_rules`
--

LOCK TABLES `seo_rules` WRITE;
/*!40000 ALTER TABLE `seo_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `seo_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sign_task`
--

DROP TABLE IF EXISTS `sign_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sign_task` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `type` bigint NOT NULL COMMENT '任务类型 1连续签到 2累计签到',
  `days` bigint NOT NULL COMMENT '天数',
  `sort` bigint NOT NULL COMMENT '排序',
  `gold_coin` bigint NOT NULL COMMENT '赠送金币数量',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `site_id` int NOT NULL DEFAULT '0',
  `member_group_id` int NOT NULL DEFAULT '0',
  `vip_days` int NOT NULL DEFAULT '0',
  `gift_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'gold',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sign_task`
--

LOCK TABLES `sign_task` WRITE;
/*!40000 ALTER TABLE `sign_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `sign_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_ads`
--

DROP TABLE IF EXISTS `site_ads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_ads` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL DEFAULT '0' COMMENT '站点id',
  `ad_id` bigint NOT NULL DEFAULT '0' COMMENT '广告id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_ads`
--

LOCK TABLES `site_ads` WRITE;
/*!40000 ALTER TABLE `site_ads` DISABLE KEYS */;
/*!40000 ALTER TABLE `site_ads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_collection`
--

DROP TABLE IF EXISTS `site_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_collection` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL DEFAULT '0',
  `log_id` bigint NOT NULL DEFAULT '0',
  `collection_id` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_collection`
--

LOCK TABLES `site_collection` WRITE;
/*!40000 ALTER TABLE `site_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `site_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_collection_log`
--

DROP TABLE IF EXISTS `site_collection_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_collection_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL DEFAULT '0' COMMENT '站点id',
  `log_id` bigint NOT NULL DEFAULT '0' COMMENT '日志id',
  `collection_id` bigint DEFAULT NULL COMMENT '采集资源id',
  `total` bigint NOT NULL DEFAULT '0' COMMENT '采集总条数',
  `success_total` bigint NOT NULL DEFAULT '0' COMMENT '采集成功条数',
  `fail_total` bigint NOT NULL DEFAULT '0' COMMENT '失败',
  `add_total` bigint NOT NULL DEFAULT '0' COMMENT '新增条数',
  `update_total` bigint NOT NULL DEFAULT '0' COMMENT '更新条数',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_site_collection_log_collection_id` (`collection_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_collection_log`
--

LOCK TABLES `site_collection_log` WRITE;
/*!40000 ALTER TABLE `site_collection_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `site_collection_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_config`
--

DROP TABLE IF EXISTS `site_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_config` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '站点名称',
  `domain` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '站点域名',
  `logo` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '站点logo(base64)',
  `icon` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '站点图标(base64)',
  `run_mode` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '站点',
  `open_cache` tinyint(1) DEFAULT NULL COMMENT '缓存开关(运行静态有效)',
  `cacheTime` smallint DEFAULT NULL COMMENT '缓存时间(运行静态有效)',
  `state` bigint DEFAULT NULL COMMENT '状态 1开启 2关闭',
  `qq` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'qq',
  `wechat` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '微信',
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '邮箱',
  `telegraph` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '电报',
  `closeReason` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '关闭原因',
  `note` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '备注(站点关闭原因等)',
  `region` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '自定义地区',
  `language` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '自定义语言',
  `label` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '自定义语言',
  `year` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '自定义年份',
  `statistical_code` text COLLATE utf8mb4_unicode_ci COMMENT '统计代码',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `visitor` bigint DEFAULT '2' COMMENT '游客状态 1开启 2关闭',
  `gzip` bigint DEFAULT '1' COMMENT 'gzip 1开启 2关闭',
  `gzip_level` bigint DEFAULT '4' COMMENT 'gzip等级',
  `apk_down_total` bigint NOT NULL DEFAULT '0' COMMENT 'android下载次数',
  `ios_down_total` bigint NOT NULL DEFAULT '0' COMMENT 'ios下载次数',
  `customer_visitor` tinyint(1) DEFAULT NULL COMMENT '客服游客状态',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `message_board_status` int NOT NULL DEFAULT '2' COMMENT 'message_board_status',
  `plugin_switch` int NOT NULL DEFAULT '15' COMMENT '会员、分销、客服、留言系统开关',
  `icp` text COLLATE utf8mb4_unicode_ci COMMENT '备案号',
  `parent_id` int NOT NULL DEFAULT '0' COMMENT '站点父级id',
  `api_cache_num` int NOT NULL DEFAULT '30000' COMMENT 'api缓存数',
  `type` int NOT NULL DEFAULT '1' COMMENT '站点类型 1:视频 2:小说 3:漫画 4:图文',
  `cami_state` int NOT NULL DEFAULT '1',
  `security_chain` int NOT NULL DEFAULT '2' COMMENT '防盗链1-开启，2-关闭',
  `refer_allow_blank` int NOT NULL DEFAULT '1' COMMENT '防盗链允许为空1-允许，2-不允许',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_config`
--

LOCK TABLES `site_config` WRITE;
/*!40000 ALTER TABLE `site_config` DISABLE KEYS */;
INSERT INTO `site_config` VALUES (1,'请修改','test.123.xyz','','','动态访问',0,600,1,'','','','','','','','','','','',1744374684,1744374684,2,1,4,0,0,0,1,2,0,'',0,30000,1,1,2,1);
/*!40000 ALTER TABLE `site_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_domain`
--

DROP TABLE IF EXISTS `site_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_domain` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `domain_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '域名',
  `remark` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `is_tls` bigint NOT NULL DEFAULT '1' COMMENT '是否强制TLS:1是 2否',
  `cert_status` bigint NOT NULL DEFAULT '0' COMMENT '证书状态:1未添加(手动) 2未申请(自动) 3申请中 4正常 5申请失败 6即将过期 7已过期 8已吊销',
  `message` text COLLATE utf8mb4_unicode_ci COMMENT '申请信息',
  `cer` text COLLATE utf8mb4_unicode_ci COMMENT '证书内容',
  `cer_key` text COLLATE utf8mb4_unicode_ci COMMENT '证书Key',
  `auto_apply` tinyint(1) DEFAULT NULL COMMENT '自动申请',
  `auto_renew` tinyint(1) DEFAULT NULL COMMENT '自动续签',
  `expired_time` bigint DEFAULT NULL COMMENT '过期时间',
  `expire_tip_time` bigint DEFAULT NULL COMMENT '过期提醒时间',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `resolver_type` bigint DEFAULT NULL COMMENT '解析方式 1http 2DNS',
  `dns_setting_id` bigint DEFAULT NULL COMMENT 'DNS配置id,解析方式位DNS时，必填',
  `show_date` bigint DEFAULT NULL COMMENT '前台作为主域名使用时间，以天为单位',
  `tls_type` bigint DEFAULT NULL COMMENT '1仅http 2仅https 3https+http 4强制https',
  `channel_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '渠道编码',
  `channel_name` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '渠道',
  `channel_bind_at` bigint NOT NULL DEFAULT '0' COMMENT '渠道绑定时间',
  `site_id` bigint NOT NULL DEFAULT '0' COMMENT '站点id',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_site_domain_domain_name` (`domain_name`),
  KEY `idx_site_domain_site_id` (`site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_domain`
--

LOCK TABLES `site_domain` WRITE;
/*!40000 ALTER TABLE `site_domain` DISABLE KEYS */;
INSERT INTO `site_domain` VALUES (1,'test.123.xyz','',2,2,'','','',0,0,0,0,1744374684,1744374684,1,0,0,1,'','',0,1);
/*!40000 ALTER TABLE `site_domain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_import_out`
--

DROP TABLE IF EXISTS `site_import_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_import_out` (
  `site_id` bigint NOT NULL DEFAULT '0' COMMENT '站点id',
  `open` smallint NOT NULL DEFAULT '0' COMMENT '是否打开',
  `code` varchar(255) NOT NULL DEFAULT '' COMMENT '免登录验证码',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `config_json` text COMMENT '配置json'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='外部入库表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_import_out`
--

LOCK TABLES `site_import_out` WRITE;
/*!40000 ALTER TABLE `site_import_out` DISABLE KEYS */;
/*!40000 ALTER TABLE `site_import_out` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_links`
--

DROP TABLE IF EXISTS `site_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_links` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL DEFAULT '0' COMMENT '站点id',
  `link_id` bigint NOT NULL DEFAULT '0' COMMENT '友情',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_links`
--

LOCK TABLES `site_links` WRITE;
/*!40000 ALTER TABLE `site_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `site_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_notice`
--

DROP TABLE IF EXISTS `site_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_notice` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL DEFAULT '0' COMMENT '站点id',
  `notice_id` bigint NOT NULL DEFAULT '0' COMMENT '公告id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_notice`
--

LOCK TABLES `site_notice` WRITE;
/*!40000 ALTER TABLE `site_notice` DISABLE KEYS */;
/*!40000 ALTER TABLE `site_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_pays`
--

DROP TABLE IF EXISTS `site_pays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_pays` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL DEFAULT '0' COMMENT '站点id',
  `pay_id` varchar(36) NOT NULL DEFAULT '' COMMENT '支付配置表id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='站点支付配置关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_pays`
--

LOCK TABLES `site_pays` WRITE;
/*!40000 ALTER TABLE `site_pays` DISABLE KEYS */;
/*!40000 ALTER TABLE `site_pays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitemap`
--

DROP TABLE IF EXISTS `sitemap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitemap` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `site_id` bigint NOT NULL DEFAULT '0' COMMENT '站点ID',
  `domain` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '域名',
  `scene` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'generate' COMMENT '域名',
  `page_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '页面类型',
  `type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '站点地图种类',
  `timer` int NOT NULL DEFAULT '2' COMMENT '是否开启定时任务 1开启',
  `status` int NOT NULL DEFAULT '0' COMMENT '状态 0待执行 1执行成功 2执行失败',
  `sort` bigint NOT NULL DEFAULT '0' COMMENT '序号',
  `config` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '其它配置',
  `message` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '消息',
  `generate_at` bigint NOT NULL DEFAULT '0' COMMENT '生成/推送时间戳',
  `created_at` bigint NOT NULL DEFAULT '0' COMMENT '创建时间戳',
  `updated_at` bigint NOT NULL DEFAULT '0' COMMENT '最近更新时间戳',
  PRIMARY KEY (`id`),
  KEY `idxSitemap_siteId_scene_timer` (`site_id`,`scene`,`timer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='站点地图表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitemap`
--

LOCK TABLES `sitemap` WRITE;
/*!40000 ALTER TABLE `sitemap` DISABLE KEYS */;
/*!40000 ALTER TABLE `sitemap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `statistic_app`
--

DROP TABLE IF EXISTS `statistic_app`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `statistic_app` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `state` bigint DEFAULT NULL COMMENT '状态 1启用 2停用用',
  `statistic_id` bigint NOT NULL DEFAULT '0' COMMENT '统计id,统计系统获取',
  `site_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '站点名称',
  `get_url` text COLLATE utf8mb4_unicode_ci COMMENT '统计数获取地址(相对地址)',
  `report_url` text COLLATE utf8mb4_unicode_ci COMMENT '统计数上报地址',
  `host` text COLLATE utf8mb4_unicode_ci COMMENT '统计数据域名',
  `supt_username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '超管登录用户名',
  `slogan` text COLLATE utf8mb4_unicode_ci COMMENT 'slogan',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  PRIMARY KEY (`id`),
  KEY `idx_statistic_app_supt_user_name` (`supt_username`),
  KEY `idx_statistic_app_statistic_id` (`statistic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statistic_app`
--

LOCK TABLES `statistic_app` WRITE;
/*!40000 ALTER TABLE `statistic_app` DISABLE KEYS */;
/*!40000 ALTER TABLE `statistic_app` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `statistic_channel`
--

DROP TABLE IF EXISTS `statistic_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `statistic_channel` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `channel_id` bigint NOT NULL DEFAULT '0' COMMENT '渠道id',
  `channel_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '唯一编码',
  `statistic_id` bigint NOT NULL DEFAULT '0' COMMENT '统计id,统计系统获取',
  `category` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '类型 app web',
  `app_id` bigint NOT NULL DEFAULT '0' COMMENT '超管返回',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_channel_id` (`channel_code`),
  KEY `idx_statistic_channel_statistic_id` (`statistic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statistic_channel`
--

LOCK TABLES `statistic_channel` WRITE;
/*!40000 ALTER TABLE `statistic_channel` DISABLE KEYS */;
/*!40000 ALTER TABLE `statistic_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `statistic_web`
--

DROP TABLE IF EXISTS `statistic_web`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `statistic_web` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `state` bigint DEFAULT NULL COMMENT '状态 1启用 2停用用',
  `statistic_id` bigint NOT NULL DEFAULT '0' COMMENT '统计id,统计系统获取',
  `site_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '站点名称',
  `supt_username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '超管登录用户名',
  `get_url` text COLLATE utf8mb4_unicode_ci COMMENT '统计数获取地址(相对地址)',
  `report_url` text COLLATE utf8mb4_unicode_ci COMMENT '统计数上报地址',
  `host` text COLLATE utf8mb4_unicode_ci COMMENT '统计数据域名',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  PRIMARY KEY (`id`),
  KEY `idx_statistic_web_statistic_id` (`statistic_id`),
  KEY `idx_statistic_web_supt_user_name` (`supt_username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statistic_web`
--

LOCK TABLES `statistic_web` WRITE;
/*!40000 ALTER TABLE `statistic_web` DISABLE KEYS */;
/*!40000 ALTER TABLE `statistic_web` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_configs`
--

DROP TABLE IF EXISTS `system_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_configs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `config_key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `update_at` bigint NOT NULL,
  `create_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_system_configs_key` (`config_key`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_configs`
--

LOCK TABLES `system_configs` WRITE;
/*!40000 ALTER TABLE `system_configs` DISABLE KEYS */;
INSERT INTO `system_configs` VALUES (1,'db_uuid','e308f08ce04d97ed5b1e968265074ce2',1744374475,1744374475),(2,'cms_collect_config_upgrade_v2','1',1744374475,1744374475),(3,'supt_auth_password','917g00ii0f99549318f0i7e5235g3545',1744374709,1744374709),(4,'supt_auth_uid','295789680796944901',1744374709,1744374709);
/*!40000 ALTER TABLE `system_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_plugin`
--

DROP TABLE IF EXISTS `system_plugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_plugin` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `hash` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '插件HASH',
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '插件logo',
  `name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '插件名称',
  `status` bigint NOT NULL DEFAULT '0' COMMENT '插件开关{0:关闭,1:开启}',
  `business_desc` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '插件业务描述',
  `setting` text COLLATE utf8mb4_unicode_ci COMMENT '配置',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hash` (`hash`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_plugin`
--

LOCK TABLES `system_plugin` WRITE;
/*!40000 ALTER TABLE `system_plugin` DISABLE KEYS */;
INSERT INTO `system_plugin` VALUES (1,'eec1544714908da92042d8624c70e537','','会员系统',1,'为您提供会员相关数据查询服务','',1744374636,1744374636),(2,'EB1DFDA777F5748E3FBC2338DA9D07B6','','分销系统',0,'推广获得收益','',1744374636,1744374636),(3,'BD5EF79F6EB14E547A87F868BCE327A3','','客服系统',0,'为您提供客服相关数据查询服务','{\"use\":1,\"local\":{\"api\":\"\",\"js\":\"\",\"scripts\":null},\"other\":{\"api\":\"\",\"js\":\"\",\"scripts\":null}}',1744374636,1744374636),(4,'53753F2A7D834F08918B0BB24AE28B84','','统计系统',0,'为您提供数据统计查询管理服务','',1744374636,1744374636),(5,'E5EAD10AECA0745008663C2CD3BEECA3','','应用管理',0,'为您提供APP应用服务','',1744374636,1744374636),(6,'5351DF655AC67329F85086F764BF27A6','','模板中心',0,'提供多样化的模板选择','',1744374636,1744374636),(7,'4E5A04110455C178C5963EDD22C56B9B','','留言系统',0,'留言求片 管理系统','',1744374636,1744374636),(8,'2E4AAF4432D7CE04090520FC2479E816','','可视化伪静态',0,'相比纯静态功能，伪静态更适合信息内容较少的企业网站，既能满足SEO优化，又能方便的管理。','',1744374636,1744374636);
/*!40000 ALTER TABLE `system_plugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `status` bigint NOT NULL,
  `priority` bigint NOT NULL,
  `fn` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `args` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '{}',
  `info` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `publish_id` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `template`
--

DROP TABLE IF EXISTS `template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `template` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '显示名',
  `type` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `status` bigint NOT NULL DEFAULT '0',
  `path` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `root` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `page_type` bigint NOT NULL DEFAULT '1' COMMENT '页面类型1-单页面，2-多页面',
  `default_index` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'index.html' COMMENT '默认首页',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  PRIMARY KEY (`id`),
  KEY `idx_template_site_id` (`site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template`
--

LOCK TABLES `template` WRITE;
/*!40000 ALTER TABLE `template` DISABLE KEYS */;
INSERT INTO `template` VALUES (1,'seo004','黑色酷炫风','all',1,'data/tpl/seo004','/app/iycms',2,'index.html',1744374718,1744374718,0);
/*!40000 ALTER TABLE `template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `template_mall_download_log`
--

DROP TABLE IF EXISTS `template_mall_download_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `template_mall_download_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `down_type` bigint DEFAULT '0' COMMENT '下载方式1-系统，2-本地',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_template_mall_download_log_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template_mall_download_log`
--

LOCK TABLES `template_mall_download_log` WRITE;
/*!40000 ALTER TABLE `template_mall_download_log` DISABLE KEYS */;
INSERT INTO `template_mall_download_log` VALUES (1,'seo004',1,1744374718,1744374718);
/*!40000 ALTER TABLE `template_mall_download_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tip_offs`
--

DROP TABLE IF EXISTS `tip_offs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tip_offs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '举报内容|举报原因',
  `comments_id` bigint NOT NULL COMMENT '评论id|视频id',
  `resource_url` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '资源地址',
  `comments_content` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '评论内容|被举报内容',
  `member_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '会员id',
  `member_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '会员名',
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '举报类型 video:视频 comment:评论',
  `recovery_time` bigint NOT NULL DEFAULT '0' COMMENT '回复时间',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tip_offs`
--

LOCK TABLES `tip_offs` WRITE;
/*!40000 ALTER TABLE `tip_offs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tip_offs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tpl_rewrite`
--

DROP TABLE IF EXISTS `tpl_rewrite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tpl_rewrite` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `path` varchar(150) NOT NULL DEFAULT '' COMMENT '页面路径',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `tag` varchar(20) NOT NULL DEFAULT '' COMMENT '标识',
  `requ_param` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `rule` text COMMENT '规则',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='模板规则';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tpl_rewrite`
--

LOCK TABLES `tpl_rewrite` WRITE;
/*!40000 ALTER TABLE `tpl_rewrite` DISABLE KEYS */;
/*!40000 ALTER TABLE `tpl_rewrite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `try_watch_config_v3`
--

DROP TABLE IF EXISTS `try_watch_config_v3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `try_watch_config_v3` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
  `open` tinyint(1) NOT NULL DEFAULT '0' COMMENT '开关',
  `type` bigint NOT NULL DEFAULT '0' COMMENT '类型：1-时长，2-集数',
  `episodes` bigint NOT NULL DEFAULT '0' COMMENT '集数',
  `duration` bigint NOT NULL DEFAULT '0' COMMENT '时长分钟',
  `second` bigint NOT NULL DEFAULT '0' COMMENT '秒数',
  `site_id` bigint NOT NULL DEFAULT '0' COMMENT '站点id',
  `ext` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '扩展信息',
  `create_at` bigint NOT NULL DEFAULT '0' COMMENT '开关',
  `update_at` bigint NOT NULL DEFAULT '0' COMMENT '开关',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='试看配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `try_watch_config_v3`
--

LOCK TABLES `try_watch_config_v3` WRITE;
/*!40000 ALTER TABLE `try_watch_config_v3` DISABLE KEYS */;
/*!40000 ALTER TABLE `try_watch_config_v3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nick_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `uuid` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `role` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `status` bigint NOT NULL DEFAULT '1',
  `last_login_ip` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `last_login_at` bigint NOT NULL,
  `permissions` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_username` (`user_name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','admin','64f1dfac-fdd1-2185-983c-783bd1951737','14e1b600b1fd579f47433b88e8d85291','1',1,'46.3.240.74',1744374636,'',1744374475,1744374475);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_line`
--

DROP TABLE IF EXISTS `video_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_line` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `video_id` bigint DEFAULT NULL,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `sort` bigint NOT NULL DEFAULT '0' COMMENT '序号',
  `player_id` bigint DEFAULT NULL COMMENT '关联播放器id',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  `tag` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '标识',
  PRIMARY KEY (`id`),
  KEY `idx_video_line_video_id` (`video_id`),
  KEY `idx_video_line_site_id` (`site_id`),
  KEY `idx_video_line_tag` (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_line`
--

LOCK TABLES `video_line` WRITE;
/*!40000 ALTER TABLE `video_line` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_on_demand`
--

DROP TABLE IF EXISTS `video_on_demand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_on_demand` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `member_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '会员uuid',
  `type` bigint NOT NULL COMMENT '购买类型 1部 2集',
  `video_id` bigint NOT NULL COMMENT '视频id',
  `playline_id` bigint NOT NULL COMMENT '播放线路id',
  `gold_coin` bigint NOT NULL COMMENT '金币数量',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  PRIMARY KEY (`id`),
  KEY `idx_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_on_demand`
--

LOCK TABLES `video_on_demand` WRITE;
/*!40000 ALTER TABLE `video_on_demand` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_on_demand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `videos`
--

DROP TABLE IF EXISTS `videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `videos` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '影片标题',
  `category_pid` bigint NOT NULL DEFAULT '0' COMMENT '分类一级id',
  `category_child_id` bigint NOT NULL DEFAULT '0' COMMENT '分类二级id',
  `surface_plot` text COLLATE utf8mb4_unicode_ci COMMENT '影片封面图',
  `recommend` bigint NOT NULL DEFAULT '2' COMMENT '是否推荐 1是 2否',
  `cycle` bigint NOT NULL DEFAULT '2' COMMENT '是否轮播 1是 2否',
  `cycle_img` text COLLATE utf8mb4_unicode_ci COMMENT '轮播图片',
  `charging_mode` bigint NOT NULL DEFAULT '0' COMMENT '收费模式 1免费 2vip免费 3金币点播',
  `buy_mode` bigint NOT NULL DEFAULT '1' COMMENT '购买模式 1按部 2按集',
  `gold` bigint NOT NULL DEFAULT '0' COMMENT '金币点播值',
  `directors` text COLLATE utf8mb4_unicode_ci COMMENT '导演',
  `actors` text COLLATE utf8mb4_unicode_ci COMMENT '演员',
  `imdb_score` bigint NOT NULL COMMENT 'imd评分.百分制',
  `imdb_score_id` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'imd评分ID',
  `douban_score` bigint NOT NULL COMMENT '豆瓣评分.百分制',
  `douban_score_id` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '豆瓣评分ID',
  `introduce` text COLLATE utf8mb4_unicode_ci COMMENT '简介',
  `popularity_day` bigint NOT NULL COMMENT '日人气',
  `popularity_week` bigint NOT NULL COMMENT '周人气',
  `popularity_month` bigint NOT NULL COMMENT '月人气',
  `popularity_sum` bigint NOT NULL COMMENT '总人气',
  `note` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '连载状态',
  `year` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '年份',
  `album_id` bigint NOT NULL COMMENT '关联专题id',
  `status` bigint NOT NULL COMMENT '状态',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  `duration` bigint NOT NULL DEFAULT '0' COMMENT '时长(单位s)',
  `region` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '自定义地区',
  `language` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '自定义语言',
  `label` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '自定义标签',
  `number` bigint DEFAULT NULL COMMENT '总集数',
  `total` bigint DEFAULT NULL COMMENT '更新集数',
  `horizontal_poster` text COLLATE utf8mb4_unicode_ci COMMENT '横屏海报',
  `vertical_poster` text COLLATE utf8mb4_unicode_ci COMMENT '竖屏海报',
  `publish` text COLLATE utf8mb4_unicode_ci COMMENT '发行商',
  `serial_number` text COLLATE utf8mb4_unicode_ci COMMENT '序列号',
  `screenshot` text COLLATE utf8mb4_unicode_ci COMMENT '截屏',
  `gif` text COLLATE utf8mb4_unicode_ci,
  `alias` text COLLATE utf8mb4_unicode_ci,
  `release_at` bigint DEFAULT NULL,
  `shelf_at` bigint NOT NULL DEFAULT '0',
  `end` tinyint(1) DEFAULT NULL,
  `unit` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `watch` bigint DEFAULT NULL,
  `collection_id` bigint DEFAULT NULL,
  `use_local_image` tinyint(1) DEFAULT NULL,
  `titles_time` int NOT NULL DEFAULT '0' COMMENT '片头时间',
  `trailer_time` int NOT NULL DEFAULT '0' COMMENT '片尾时间',
  `site_id` int NOT NULL DEFAULT '1' COMMENT '站点id',
  `category_pid_status` int NOT NULL DEFAULT '1' COMMENT '顶级分类状态',
  `category_child_id_status` int NOT NULL DEFAULT '1' COMMENT '子级分类状态',
  `play_url` longtext COLLATE utf8mb4_unicode_ci COMMENT '采集的源地址',
  `play_url_put_in` int NOT NULL DEFAULT '0' COMMENT '播放地址是否入库1-已经入库',
  PRIMARY KEY (`id`),
  UNIQUE KEY `videos_spct_uidx` (`site_id`,`category_pid`,`category_child_id`,`title`),
  KEY `videos_release_at_index` (`release_at`),
  KEY `videos_cycle_index` (`site_id`,`cycle`,`recommend`,`shelf_at`),
  KEY `videos_scs_index` (`site_id`,`category_child_id`,`shelf_at`),
  KEY `videos_shelfat_query_index` (`site_id`,`category_pid`,`shelf_at`),
  KEY `videos_watch_query_index` (`site_id`,`category_pid`,`watch`),
  KEY `videos_recommend_query_index` (`site_id`,`recommend`,`shelf_at`),
  KEY `idx_videos_shelfAt` (`site_id`,`shelf_at`),
  KEY `idx_videos_siteID_pid_cid` (`site_id`,`category_pid`,`category_child_id`),
  KEY `idx_videos_siteID_title` (`site_id`,`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `videos`
--

LOCK TABLES `videos` WRITE;
/*!40000 ALTER TABLE `videos` DISABLE KEYS */;
/*!40000 ALTER TABLE `videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `videos_attribute`
--

DROP TABLE IF EXISTS `videos_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `videos_attribute` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `videos_id` bigint DEFAULT NULL COMMENT '影片id',
  `label_id` bigint NOT NULL DEFAULT '0' COMMENT '标签id',
  `theme_id` bigint NOT NULL DEFAULT '0' COMMENT '题材id',
  `language_id` bigint NOT NULL DEFAULT '0' COMMENT '语言id',
  `region_id` bigint NOT NULL DEFAULT '0' COMMENT '地区id',
  `create_at` bigint NOT NULL DEFAULT '0',
  `update_at` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_labelid` (`label_id`),
  KEY `idx_themeid` (`theme_id`),
  KEY `idx_languageid` (`language_id`),
  KEY `idx_regionid` (`region_id`),
  KEY `idx_videoid` (`videos_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `videos_attribute`
--

LOCK TABLES `videos_attribute` WRITE;
/*!40000 ALTER TABLE `videos_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `videos_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `welcome_words`
--

DROP TABLE IF EXISTS `welcome_words`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `welcome_words` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL COMMENT '用户id',
  `sort` bigint DEFAULT '0',
  `content` text COLLATE utf8mb4_unicode_ci COMMENT '内容',
  `trigger_event` bigint DEFAULT NULL COMMENT '触发事件1-初次连接，2-转接,3-结束服务,4-自动回复',
  `auto_reply_interval` bigint DEFAULT NULL COMMENT '自动回复时间间隔，分钟',
  `status` bigint NOT NULL DEFAULT '1',
  `create_at` bigint NOT NULL,
  `update_at` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `welcome_words`
--

LOCK TABLES `welcome_words` WRITE;
/*!40000 ALTER TABLE `welcome_words` DISABLE KEYS */;
/*!40000 ALTER TABLE `welcome_words` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'iycms'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-11 12:32:31
